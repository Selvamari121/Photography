package com.companyname.projectname.crm.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyname.projectname.crm.dto.ScheduleDto;
import com.companyname.projectname.crm.dto.ScheduleExpiredDto;
import com.companyname.projectname.crm.model.ScheduleEntity;
import com.companyname.projectname.crm.repository.ScheduleRepository;
import com.companyname.projectname.exception.ItemNotFoundException;
import com.companyname.projectname.util.KeyIdConversion;

@Service
public class ScheduleService {
	@Autowired
	private ScheduleRepository scheduleRepository;

	@Autowired
	private KeyIdConversion conversion;

	public void createSchedule(ScheduleEntity schedule) {
		int projectKey = conversion.IdToKeyConversion(schedule.getProjectId(), 2);
		ScheduleEntity scheduleEntity = new ScheduleEntity();
		scheduleEntity.setProjectKey(projectKey);
		scheduleEntity.setScheduleAmount(schedule.getScheduleAmount());
		scheduleEntity.setPaymentDueDate(schedule.getPaymentDueDate());
		scheduleEntity.setIsPaid(schedule.getIsPaid());
		scheduleEntity.setPaymentDate(schedule.getPaymentDate());
		scheduleRepository.save(scheduleEntity);
	}

	public List<ScheduleDto> getAllSchedules(String projectId) {
		int projectKey = conversion.IdToKeyConversion(projectId, 2);
		return scheduleRepository.findAllSchedule(projectKey);
	}

	public List<ScheduleExpiredDto> getAllExpiredSchedule(int photographerId) {
		LocalDateTime currentDateTime = LocalDateTime.now();
		return scheduleRepository.findExpiredSchedules(currentDateTime, photographerId);
	}

	public ScheduleDto getScheduleById(String scheduleId) {
		int scheduleKey = conversion.IdToKeyConversion(scheduleId, 2);
		return scheduleRepository.findByScheduleKey(scheduleKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public void updateSchedule(String scheduleId, ScheduleEntity updatedSchedule) {
		int scheduleKey = conversion.IdToKeyConversion(scheduleId, 2);
		ScheduleEntity existingSchedule = scheduleRepository.findById(scheduleKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
		existingSchedule.setScheduleAmount(updatedSchedule.getScheduleAmount());
		existingSchedule.setPaymentDueDate(updatedSchedule.getPaymentDueDate());
		existingSchedule.setIsPaid(updatedSchedule.getIsPaid());
		existingSchedule.setPaymentDate(updatedSchedule.getPaymentDate());
		scheduleRepository.save(existingSchedule);
	}

	public void deleteScheduleById(String scheduleId) {
		int scheduleKey = conversion.IdToKeyConversion(scheduleId, 2);
		if (!scheduleRepository.existsById(scheduleKey)) {
			throw new ItemNotFoundException("Item not found. Please try again.");
		}
		scheduleRepository.deleteById(scheduleKey);
	}

	// // Interval
	// public BigDecimal getAmountByPaymentDate(LocalDateTime startDate, LocalDateTime endDate, int photographerId) {
	// 	return scheduleRepository.findAmountByPaymentDate(startDate, endDate, photographerId).orElse(BigDecimal.ZERO);
	// }

	// // Interval
	// public BigDecimal getAmountByDueDate(LocalDateTime startDate, LocalDateTime endDate, int photographerId) {
	// 	return scheduleRepository.findAmountByDueDate(startDate, endDate, photographerId).orElse(BigDecimal.ZERO);
	// }

	// // Overall
	// public BigDecimal getTotalPaidAmount(int photographerId) {
	// 	return scheduleRepository.findTotalPaidAmount(photographerId).orElse(BigDecimal.ZERO);
	// }

	// // Overall
	// public BigDecimal getTotalAmount(int photographerId) {
	// 	return scheduleRepository.findTotalAmount(photographerId).orElse(BigDecimal.ZERO);
	// }

}
