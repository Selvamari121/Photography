package com.companyname.projectname.crm.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class EventTypeDto {
	private String eventTypeId;

	private String name;

	private String description;

	private String projectTypeId;

	private String projectTypeName;
}
