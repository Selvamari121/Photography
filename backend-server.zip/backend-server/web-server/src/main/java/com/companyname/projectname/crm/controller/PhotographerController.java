package com.companyname.projectname.crm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.authentication.service.SecurityService;
import com.companyname.projectname.crm.service.PhotographerService;

import jakarta.validation.Valid;

import com.companyname.projectname.crm.dto.PhotographerDto;
import com.companyname.projectname.crm.model.PhotographerEntity;

@RestController
@RequestMapping("/api/photographer")
public class PhotographerController {

	@Autowired
	private PhotographerService photographerService;

	@Autowired
	private SecurityService securityService;

	// TODO: Why this functionality?
	@GetMapping("/dashboard/home")
	public ResponseEntity<Void> getPhotographerDashboard() {
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@GetMapping("/dashboard/user")
	public ResponseEntity<String> getPhotographerName() {
		int photographerKey = securityService.getPhotographerKey();
		String photographerName = photographerService.getPhotographerName(photographerKey);
		return ResponseEntity.status(HttpStatus.OK).body(photographerName);
	}

	@GetMapping("/dashboard/initials")
	public ResponseEntity<String> getPhotographerInitials() {
		int photographerKey = securityService.getPhotographerKey();
		String initials = photographerService.getPhotographerInitials(photographerKey);
		return ResponseEntity.status(HttpStatus.OK).body(initials);
	}

	@GetMapping("/profile")
	public ResponseEntity<PhotographerDto> getPhotographerDetails() {
		int photographerKey = securityService.getPhotographerKey();
		PhotographerDto photographerData = photographerService.getPhotographerDetails(photographerKey);
		return ResponseEntity.status(HttpStatus.OK).body(photographerData);
	}

	@PatchMapping("/profile")
	public ResponseEntity<Void> updatePhotographer(@Valid @RequestBody PhotographerEntity updatePhotographer) {
		int photographerKey = securityService.getPhotographerKey();
		photographerService.updatePhotographer(photographerKey, updatePhotographer);
		return ResponseEntity.status(HttpStatus.OK).build();
	}
}
