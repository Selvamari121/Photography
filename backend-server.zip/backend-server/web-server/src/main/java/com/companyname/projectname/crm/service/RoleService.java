package com.companyname.projectname.crm.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyname.projectname.crm.dto.RoleDto;
import com.companyname.projectname.crm.model.RoleEntity;
import com.companyname.projectname.crm.repository.RoleRepository;
import com.companyname.projectname.exception.ItemNotFoundException;
import com.companyname.projectname.util.KeyIdConversion;

@Service
public class RoleService {
	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private KeyIdConversion conversion;

	public void createRole(RoleEntity role) {
		roleRepository.save(role);
	}

	public List<RoleDto> findAllRoles() {
		return roleRepository.findAllRole();
	}

	public RoleDto getRoleById(String roleId) {
		int roleKey = conversion.IdToKeyConversion(roleId, 2);
		return roleRepository.findByRoleKey(roleKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public void updateRole(String roleId, RoleEntity updatedRole) {
		int roleKey = conversion.IdToKeyConversion(roleId, 2);
		RoleEntity existingRole = roleRepository.findById(roleKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
		existingRole.setName(updatedRole.getName());
		existingRole.setDescription(updatedRole.getDescription());
		roleRepository.save(existingRole);
	}

	public void deleteRoleById(String roleId) {
		int roleKey = conversion.IdToKeyConversion(roleId, 2);
		if (!roleRepository.existsById(roleKey)) {
			throw new ItemNotFoundException("Item not found. Please try again.");
		}
		roleRepository.deleteById(roleKey);
	}
}
