package com.companyname.projectname.crm.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyname.projectname.crm.dto.PlanCustomerDto;
import com.companyname.projectname.crm.model.PlanCustomerEntity;
import com.companyname.projectname.crm.repository.PlanCustomerRepository;
import com.companyname.projectname.exception.ItemNotFoundException;
import com.companyname.projectname.util.KeyIdConversion;

@Service
public class PlanCustomerService {
	@Autowired
	private PlanCustomerRepository planCustomerRepository;

	@Autowired
	private KeyIdConversion conversion;

	public void createPlanCustomer(PlanCustomerEntity planCustomers) {
		planCustomerRepository.save(planCustomers);
	}

	public List<PlanCustomerDto> getAllPlanCustomers() {
		return planCustomerRepository.findAllPlanCustomer();
	}

	public PlanCustomerDto getPlanCustomerById(String planCustomerId) {
		int PlanCustomerKey = conversion.IdToKeyConversion(planCustomerId, 3);
		return planCustomerRepository.findByPlanCustomerKey(PlanCustomerKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public void updatePlanCustomer(String planCustomerId, PlanCustomerEntity updatedPlanCustomer) {
		int PlanCustomerKey = conversion.IdToKeyConversion(planCustomerId, 3);
		PlanCustomerEntity existingPlanCustomer = planCustomerRepository.findById(PlanCustomerKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
		existingPlanCustomer.setName(updatedPlanCustomer.getName());
		existingPlanCustomer.setCost(updatedPlanCustomer.getCost());
		existingPlanCustomer.setFeatures(updatedPlanCustomer.getFeatures());
		existingPlanCustomer.setDescription(updatedPlanCustomer.getDescription());
		planCustomerRepository.save(existingPlanCustomer);
	}

	public void deletePlanCustomerById(String planCustomerId) {
		int PlanCustomerKey = conversion.IdToKeyConversion(planCustomerId, 3);
		if (!planCustomerRepository.existsById(PlanCustomerKey)) {
			throw new ItemNotFoundException("Item not found. Please try again.");
		}
		planCustomerRepository.deleteById(PlanCustomerKey);
	}
}
