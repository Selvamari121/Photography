package com.companyname.projectname.crm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyname.projectname.crm.dto.PhotographerDto;
import com.companyname.projectname.crm.model.PhotographerEntity;
import com.companyname.projectname.crm.repository.PhotographerRepository;
import com.companyname.projectname.exception.ItemNotFoundException;

@Service
public class PhotographerService {

	@Autowired
	private PhotographerRepository photographerRepository;

	public void updatePhotographer(int photographerKey, PhotographerEntity updatePhotographer) {
		PhotographerEntity existingPhotographer = photographerRepository.findById(photographerKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));

		existingPhotographer.setFirstName(updatePhotographer.getFirstName());
		existingPhotographer.setLastName(updatePhotographer.getLastName());
		existingPhotographer.setCompanyName(updatePhotographer.getCompanyName());
		existingPhotographer.setAddressLine1(updatePhotographer.getAddressLine1());
		existingPhotographer.setAddressLine2(updatePhotographer.getAddressLine2());
		existingPhotographer.setCity(updatePhotographer.getCity());
		existingPhotographer.setState(updatePhotographer.getState());
		existingPhotographer.setCountry(updatePhotographer.getCountry());
		existingPhotographer.setPinCode(updatePhotographer.getPinCode());
		existingPhotographer.setPanNo(updatePhotographer.getPanNo());
		existingPhotographer.setAadharNo(updatePhotographer.getAadharNo());
		existingPhotographer.setGstNo(updatePhotographer.getGstNo());
		photographerRepository.save(existingPhotographer);
	}

	public PhotographerDto getPhotographerDetails(int photographerKey) {
		return photographerRepository.findPhotographerByKey(photographerKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public String getPhotographerName(int photographerKey) {
		return photographerRepository.findNameByKey(photographerKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public String getPhotographerInitials(int photographerKey) {
		PhotographerEntity photographer = photographerRepository.findById(photographerKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));

		String userName = photographer.getFirstName();

		String[] nameParts = userName != null ? userName.split(" ") : new String[0];

		String initials = "";
		if (nameParts.length > 0) {
			initials += nameParts[0].charAt(0); // First name initial
		}
		if (nameParts.length > 1) {
			initials += nameParts[nameParts.length - 1].charAt(0); // Last name initial
		}
		return initials.toUpperCase();
	}
}
