package com.companyname.projectname.crm.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.authentication.service.SecurityService;
import com.companyname.projectname.crm.dto.EventDto;
import com.companyname.projectname.crm.dto.EventMonthDto;
import com.companyname.projectname.crm.service.EventService;

@RestController
@RequestMapping("/api/photographer/events")
public class CalendarController {

	@Autowired
	private EventService eventService;

	@Autowired
	private SecurityService securityService;

	@GetMapping("/month")
	public ResponseEntity<List<EventMonthDto>> getEventsByMonth(@RequestParam("year") Integer year,
			@RequestParam("month") Integer month) {
		int photographerKey = securityService.getPhotographerKey();
		List<EventMonthDto> eventMonthList = eventService.findByYearAndMonth(year, month, photographerKey);
		return ResponseEntity.status(HttpStatus.OK).body(eventMonthList);
	}

	@GetMapping("/year")
	public ResponseEntity<List<Date>> getYearEvents(@RequestParam("year") Integer year) {
		int photographerKey = securityService.getPhotographerKey();
		List<Date> eventYearList = eventService.getYearEvents(year, photographerKey);
		return ResponseEntity.status(HttpStatus.OK).body(eventYearList);
	}

	@GetMapping("/week/day")
	public ResponseEntity<List<EventDto>> getEventByFromEndDate(
			@RequestParam("fromDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
			@RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
		int photographerKey = securityService.getPhotographerKey();
		List<EventDto> eventWeekDayList = eventService.getEventByFromEndDate(fromDate, endDate, photographerKey);
		return ResponseEntity.status(HttpStatus.OK).body(eventWeekDayList);
	}

	@GetMapping("/date")
	public ResponseEntity<List<EventDto>> getEventByDate(
			@RequestParam("date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
		int photographerKey = securityService.getPhotographerKey();
		List<EventDto> eventDateList = eventService.getEventByDate(date, photographerKey);
		return ResponseEntity.status(HttpStatus.OK).body(eventDateList);
	}
}
