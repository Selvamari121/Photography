package com.companyname.projectname.crm.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class RoleDto {
	private String roleId;

	private String name;

	private String description;
}
