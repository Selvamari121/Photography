package com.companyname.projectname.crm.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class EventMonthDto {
	private String eventId;

	private LocalDateTime fromDateTime;

	private LocalDateTime toDateTime;

	private String eventTypeId;

	private String eventType;
}