package com.companyname.projectname.crm.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "project")
public class ProjectEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_prid")
	private int projectKey;

	@Column(name = "prid")
	private String projectId;

	@Column(name = "fk_phid")
	private int photographerKey;

	@Column(name = "fk_cuid")
	private Integer customerKey;

	@NotBlank(message = "Project name cannot be blank")
	@Size(max = 50, message = "Project name cannot exceed 50 characters")
	@Column(name = "name")
	private String projectName;

	@Column(name = "fk_prtid")
	private int projectTypeKey;

	@Column(name = "create_date")
	private LocalDate createDate;

	@Column(name = "payment_date")
	private LocalDate paymentDate;

	@Column(name = "fk_plcuid")
	private Integer planCustomerKey;

	@Transient
	private String projectTypeId;

}
