package com.companyname.projectname.crm.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.crm.dto.PlanPhotographerDto;
import com.companyname.projectname.crm.model.PlanPhotographerEntity;
import com.companyname.projectname.crm.service.PlanPhotographerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/photographer/plan-photographer")
public class PlanPhotographerController {
	@Autowired
	private PlanPhotographerService planPhotographerService;

	@PostMapping
	public ResponseEntity<Void> createPlanPhotographer(@Valid @RequestBody PlanPhotographerEntity planPhotographers) {
		planPhotographerService.createPlanPhotographer(planPhotographers);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@GetMapping
	public ResponseEntity<List<PlanPhotographerDto>> getAllPlanPhotographers() {
		List<PlanPhotographerDto> planPhotograperList = planPhotographerService.getAllPlanPhotographers();
		return ResponseEntity.status(HttpStatus.OK).body(planPhotograperList);
	}

	@GetMapping("/{planPhotographerId}")
	public ResponseEntity<PlanPhotographerDto> getPlanPhotographerById(@PathVariable String planPhotographerId) {
		PlanPhotographerDto planPhotograperData = planPhotographerService.getPlanPhotographerById(planPhotographerId);
		return ResponseEntity.status(HttpStatus.OK).body(planPhotograperData);
	}

	@PutMapping("/{planPhotographerId}")
	public ResponseEntity<Void> updatePlanPhotographer(@PathVariable String planPhotographerId,
			@Valid @RequestBody PlanPhotographerEntity planPhotograpers) {
		planPhotographerService.updatePlanPhotographer(planPhotographerId, planPhotograpers);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@DeleteMapping("/{planPhotographerId}")
	public ResponseEntity<Void> deletePlanPhotographerById(@PathVariable String planPhotographerId) {
		planPhotographerService.deletePlanPhotographerById(planPhotographerId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}
}
