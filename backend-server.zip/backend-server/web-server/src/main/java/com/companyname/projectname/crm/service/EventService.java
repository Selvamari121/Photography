package com.companyname.projectname.crm.service;

import java.sql.Date;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyname.projectname.crm.dto.EventDto;
import com.companyname.projectname.crm.dto.EventMonthDto;
import com.companyname.projectname.crm.model.EventEntity;
import com.companyname.projectname.crm.repository.EventRepository;
import com.companyname.projectname.exception.ItemNotFoundException;
import com.companyname.projectname.util.KeyIdConversion;

@Service
public class EventService {

	@Autowired
	private EventRepository eventRepository;

	@Autowired
	private KeyIdConversion conversion;

	public void createEvent(EventEntity event) {
		int projectKey = conversion.IdToKeyConversion(event.getProjectId(), 2);
		int eventTypeKey = conversion.IdToKeyConversion(event.getEventTypeId(), 3);
		EventEntity eventEntity = new EventEntity();
		eventEntity.setProjectKey(projectKey);
		eventEntity.setFromDateTime(event.getFromDateTime());
		eventEntity.setToDateTime(event.getToDateTime());
		eventEntity.setEventTypeKey(eventTypeKey);
		eventEntity.setAddressLink(event.getAddressLink());
		eventEntity.setAddressLine1(event.getAddressLine1());
		eventEntity.setAddressLine2(event.getAddressLine2());
		eventEntity.setCity(event.getCity());
		eventEntity.setState(event.getState());
		eventEntity.setCountry(event.getCountry());
		eventEntity.setPinCode(event.getPinCode());
		eventEntity.setDescription(event.getDescription());
		eventRepository.save(eventEntity);
	}

	public List<EventDto> getAllEventsByProjectId(String projectId) {
		int projectKey = conversion.IdToKeyConversion(projectId, 2);
		List<EventDto> eventList = eventRepository.findAllByProjectKey(projectKey);
		return eventList;
	}

	public EventDto getEventById(String eventId) {
		int eventKey = conversion.IdToKeyConversion(eventId, 2);
		return eventRepository.findByEventKey(eventKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public void updateEvent(String eventId, EventEntity event) {
		int eventKey = conversion.IdToKeyConversion(eventId, 2);
		EventEntity existingEvent = eventRepository.findById(eventKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));

		int projectKey = conversion.IdToKeyConversion(event.getProjectId(), 2);
		int eventTypeKey = conversion.IdToKeyConversion(event.getEventTypeId(), 3);
		existingEvent.setProjectKey(projectKey);
		existingEvent.setFromDateTime(event.getFromDateTime());
		existingEvent.setToDateTime(event.getToDateTime());
		existingEvent.setEventTypeKey(eventTypeKey);
		existingEvent.setAddressLink(event.getAddressLink());
		existingEvent.setAddressLine1(event.getAddressLine1());
		existingEvent.setAddressLine2(event.getAddressLine2());
		existingEvent.setCity(event.getCity());
		existingEvent.setState(event.getState());
		existingEvent.setCountry(event.getCountry());
		existingEvent.setPinCode(event.getPinCode());
		existingEvent.setDescription(event.getDescription());
		eventRepository.save(existingEvent);
	}

	public void deleteEvent(String eventId) {
		int eventKey = conversion.IdToKeyConversion(eventId, 2);
		if (!eventRepository.existsById(eventKey)) {
			throw new ItemNotFoundException("Item not found. Please try again.");
		}
		eventRepository.deleteById(eventKey);
	}

	public List<EventMonthDto> findByYearAndMonth(int year, int month, int photographerKey) {
		LocalDate startOfMonth = LocalDate.of(year, month, 1);
		LocalDate endOfMonth = startOfMonth.withDayOfMonth(startOfMonth.lengthOfMonth());

		LocalDate startDate = startOfMonth.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));
		LocalDate endDate = endOfMonth.with(TemporalAdjusters.nextOrSame(DayOfWeek.SATURDAY));

		LocalDateTime startDateTime = startDate.atStartOfDay();
		LocalDateTime endDateTime = endDate.atTime(23, 59, 59, 999999999);

		List<EventMonthDto> eventMonthList = eventRepository.findByYearAndMonth(startDateTime, endDateTime,
				photographerKey);
		return eventMonthList;
	}

	public List<Date> getYearEvents(Integer year, int photographerKey) {
		LocalDateTime startOfYear = LocalDateTime.of(year, Month.JANUARY, 1, 0, 0);
		LocalDateTime endOfYear = LocalDateTime.of(year, Month.DECEMBER, 31, 23, 59, 59, 999999999);

		List<Date> eventYearList = eventRepository.findDistinctDatesByYear(startOfYear, endOfYear, photographerKey);
		return eventYearList;
	}

	public List<EventDto> getEventByDate(LocalDate date, int photographerKey) {
		LocalDateTime startOfDay = date.atStartOfDay();
		LocalDateTime endOfDay = date.atTime(23, 59, 59, 999999999);

		List<EventDto> eventDateList = eventRepository.findByDateRange(startOfDay, endOfDay, photographerKey);
		return eventDateList;
	}

	public List<EventDto> getEventByFromEndDate(LocalDate fromDate, LocalDate endDate, int photographerKey) {
		LocalDateTime startOfDay = fromDate.atStartOfDay();
		LocalDateTime endOfDay = endDate.atTime(23, 59, 59, 999999999);
		List<EventDto> eventDayWeekList = eventRepository.findByDateRange(startOfDay, endOfDay, photographerKey);
		return eventDayWeekList;
	}
}
