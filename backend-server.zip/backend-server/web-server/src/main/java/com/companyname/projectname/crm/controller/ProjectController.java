package com.companyname.projectname.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.authentication.service.SecurityService;
import com.companyname.projectname.crm.dto.ProjectDto;
import com.companyname.projectname.crm.model.ProjectEntity;
import com.companyname.projectname.crm.service.ProjectService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/photographer/projects")
public class ProjectController {
	@Autowired
	private ProjectService projectService;

	@Autowired
	private SecurityService securityService;

	@PostMapping
	public ResponseEntity<Void> createProject(@Valid @RequestBody ProjectEntity project) {
		projectService.createProject(project);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@GetMapping
	public ResponseEntity<List<ProjectDto>> getAllProject() {
		int photographerKey = securityService.getPhotographerKey();
		List<ProjectDto> projectList = projectService.getAllProject(photographerKey);
		return ResponseEntity.status(HttpStatus.OK).body(projectList);
	}

	@GetMapping("/{projectId}")
	public ResponseEntity<ProjectDto> getProjectById(@PathVariable String projectId) {
		ProjectDto projectData = projectService.getProjectById(projectId);
		return ResponseEntity.status(HttpStatus.OK).body(projectData);
	}

	@PutMapping("/{projectId}")
	public ResponseEntity<Void> updateProject(@PathVariable String projectId,
			@Valid @RequestBody ProjectEntity project) {
		projectService.updateProject(projectId, project);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@DeleteMapping("/{projectId}")
	public ResponseEntity<Void> deleteProjectById(@PathVariable String projectId) {
		projectService.deleteProjectById(projectId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}
}
