package com.companyname.projectname.authentication.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.companyname.projectname.authentication.model.UserEntity;
import com.companyname.projectname.authentication.respository.UserRepository;

@Service
public class MyUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository userRepo;

	private static final String PHONE_REGEX = "^\\d{10}$";
	private static final String EMAIL_REGEX = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<UserEntity> userOptional = null;
		UserEntity user = null;
		String userNameValue = null;

		if (username.matches(EMAIL_REGEX)) {
			userOptional = userRepo.findByEmail(username);
			if (userOptional.isPresent()) {
				user = userOptional.get();
				userNameValue = user.getEmail();
			}
		} else if (username.matches(PHONE_REGEX)) {
			userOptional = userRepo.findByPhoneNo(username);
			if (userOptional.isPresent()) {
				user = userOptional.get();
				userNameValue = user.getPhoneNo();
			}
		}

		if (user != null) {
			return org.springframework.security.core.userdetails.User.builder().username(userNameValue)
					.password(user.getPassword()).build();
		}

		throw new UsernameNotFoundException("User not found with username: " + userNameValue);
	}
}
