package com.companyname.projectname.crm.repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.companyname.projectname.crm.dto.ScheduleDto;
import com.companyname.projectname.crm.dto.ScheduleExpiredDto;
import com.companyname.projectname.crm.model.ScheduleEntity;

public interface ScheduleRepository extends JpaRepository<ScheduleEntity, Integer> {

	@Query("SELECT new com.companyname.projectname.crm.dto.ScheduleDto(s.scheduleId, s.scheduleAmount, s.paymentDueDate, s.isPaid, s.paymentDate) "
			+ "FROM ScheduleEntity s " + "WHERE s.scheduleKey = :scheduleKey ")
	Optional<ScheduleDto> findByScheduleKey(@Param("scheduleKey") int scheduleKey);

	@Query("SELECT new com.companyname.projectname.crm.dto.ScheduleDto(s.scheduleId, s.scheduleAmount, s.paymentDueDate, s.isPaid, s.paymentDate) "
			+ "FROM ScheduleEntity s " + "WHERE s.projectKey = :projectKey ")
	List<ScheduleDto> findAllSchedule(@Param("projectKey") int projectKey);

	@Query("SELECT new com.companyname.projectname.crm.dto.ScheduleExpiredDto(s.scheduleId, p.projectName, s.scheduleAmount, s.paymentDueDate, s.isPaid) "
			+ "FROM ScheduleEntity s " + "JOIN ProjectEntity p ON s.projectKey = p.projectKey "
			+ "WHERE p.photographerKey = :photographerKey " + "AND s.isPaid = false AND s.paymentDueDate < :dateTime ")
	List<ScheduleExpiredDto> findExpiredSchedules(@Param("dateTime") LocalDateTime dateTime,
			@Param("photographerKey") int photographerKey);

	// @Query("SELECT SUM(s.scheduleAmount) " +
	// "FROM ScheduleEntity s " + "JOIN ProjectEntity p ON s.projectKey =
	// p.projectKey " +
	// "WHERE s.paymentDate >= :startDate " + "AND s.paymentDate <= :endDate " +
	// "AND p.photographerKey = :photographerKey")
	// Optional<BigDecimal> findAmountByPaymentDate(@Param("startDate")
	// LocalDateTime startDate,
	// @Param("endDate") LocalDateTime endDate,
	// @Param("photographerKey") int photographerKey);

	// @Query("SELECT SUM(s.scheduleAmount) " +
	// "FROM ScheduleEntity s " + "JOIN ProjectEntity p ON s.projectKey =
	// p.projectKey " +
	// "WHERE s.paymentDueDate >= :startDate " + "AND s.paymentDueDate <= :endDate "
	// +
	// "AND p.photographerKey = :photographerKey")
	// Optional<BigDecimal> findAmountByDueDate(@Param("startDate") LocalDateTime
	// startDate,
	// @Param("endDate") LocalDateTime endDate,
	// @Param("photographerKey") int photographerKey);

	// @Query("SELECT SUM(s.scheduleAmount) " +
	// "FROM ScheduleEntity s " + "JOIN ProjectEntity p ON s.projectKey =
	// p.projectKey " +
	// "WHERE s.isPaid = TRUE " + "AND p.photographerKey = :photographerKey")
	// Optional<BigDecimal> findTotalPaidAmount(@Param("photographerKey") int
	// photographerKey);

	// @Query("SELECT SUM(s.scheduleAmount) " +
	// "FROM ScheduleEntity s " + "JOIN ProjectEntity p ON s.projectKey =
	// p.projectKey " +
	// "WHERE p.photographerKey = :photographerKey")
	// Optional<BigDecimal> findTotalAmount(@Param("photographerKey") int
	// photographerKey);
}
