package com.companyname.projectname.crm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyname.projectname.crm.dto.EventTypeDto;
import com.companyname.projectname.crm.model.EventTypeEntity;
import com.companyname.projectname.crm.repository.EventTypeRepository;
import com.companyname.projectname.exception.ItemNotFoundException;
import com.companyname.projectname.util.KeyIdConversion;

@Service
public class EventTypeService {
	@Autowired
	private EventTypeRepository eventTypeRepository;

	@Autowired
	private KeyIdConversion conversion;

	public void createEventType(EventTypeEntity eventTypes) {
		int projectTypeKey = conversion.IdToKeyConversion(eventTypes.getProjectTypeId(), 3);
		EventTypeEntity eventType = new EventTypeEntity();
		eventType.setName(eventTypes.getName());
		eventType.setDescription(eventTypes.getDescription());
		eventType.setProjectTypeKey(projectTypeKey);

		eventTypeRepository.save(eventType);
	}

	public List<EventTypeDto> getAllEventTypes() {
		return eventTypeRepository.findAllEventType();
	}

	public EventTypeDto getEventTypeById(String eventTypeId) {
		int eventTypeKey = conversion.IdToKeyConversion(eventTypeId, 3);
		return eventTypeRepository.findByEventTypeKey(eventTypeKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public void updateEventType(String eventTypeId, EventTypeEntity eventTypes) {
		int eventTypeKey = conversion.IdToKeyConversion(eventTypeId, 3);
		EventTypeEntity existingEventType = eventTypeRepository.findById(eventTypeKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
		int projectTypeKey = conversion.IdToKeyConversion(eventTypes.getProjectTypeId(), 3);
		existingEventType.setName(eventTypes.getName());
		existingEventType.setDescription(eventTypes.getDescription());
		existingEventType.setProjectTypeKey(projectTypeKey);
		eventTypeRepository.save(existingEventType);
	}

	public void deleteEventTypeById(String eventTypeId) {
		int eventTypeKey = conversion.IdToKeyConversion(eventTypeId, 3);
		if (!eventTypeRepository.existsById(eventTypeKey)) {
			throw new ItemNotFoundException("Item not found. Please try again.");
		}
		eventTypeRepository.deleteById(eventTypeKey);
	}
}
