package com.companyname.projectname.crm.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.crm.dto.ProjectTypeDto;
import com.companyname.projectname.crm.model.ProjectTypeEntity;
import com.companyname.projectname.crm.service.ProjectTypeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("api/photographer/project-type")
public class ProjectTypeController {
	@Autowired
	private ProjectTypeService projectTypeService;

	@PostMapping
	public ResponseEntity<Void> createProjectType(@Valid @RequestBody ProjectTypeEntity projectTypes) {
		projectTypeService.createProjectType(projectTypes);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@GetMapping
	public ResponseEntity<List<ProjectTypeDto>> getAllProjectTypes() {
		List<ProjectTypeDto> projectTypeList = projectTypeService.getAllProjectTypes();
		return ResponseEntity.status(HttpStatus.OK).body(projectTypeList);
	}

	@GetMapping("/{projectTypeId}")
	public ResponseEntity<ProjectTypeDto> getProjectTypeById(@PathVariable String projectTypeId) {
		ProjectTypeDto projectTypeData = projectTypeService.getProjectTypeById(projectTypeId);
		return ResponseEntity.status(HttpStatus.OK).body(projectTypeData);
	}

	@PutMapping("/{projectTypeId}")
	public ResponseEntity<Void> updateProjectType(@PathVariable String projectTypeId,
			@Valid @RequestBody ProjectTypeEntity projectTypes) {
		projectTypeService.updateProjectType(projectTypeId, projectTypes);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@DeleteMapping("/{projectTypeId}")
	public ResponseEntity<Void> deleteProjectTypeById(@PathVariable String projectTypeId) {
		projectTypeService.deleteProjectTypeById(projectTypeId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}
}
