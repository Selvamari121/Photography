package com.companyname.projectname.authentication.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "muser")
public class UserEntity {
	@Id // TODO: ID in db?
	@NotBlank(message = "Phone number cannot be blank")
	@Size(max = 10, message = "Phone number cannot exceed 10 characters")
	@Column(name = "phone_number")
	private String phoneNo;

	@NotBlank(message = "Email cannot be blank")
	@Size(max = 25, message = "Email cannot exceed 25 characters")
	@Email(message = "Please enter a valid email address")
	@Column(name = "email")
	private String email;

	@NotBlank(message = "Password cannot be blank")
	@Size(max = 100, message = "Password cannot exceed 100 characters")
	@Column(name = "password")
	private String password;

	@Column(name = "active")
	private boolean active;

	@Column(name = "type")
	private String type;

	@Column(name = "fk_phid")
	private Integer photographerKey;

	@Column(name = "fk_cuid")
	private Integer customerkey;
}
