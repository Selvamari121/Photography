// package com.companyname.projectname.crm.controller;

// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.RequestParam;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;

// import java.io.IOException;
// import java.util.List;
// import java.util.stream.Collectors;
// import java.util.stream.Stream;

// import com.fasterxml.jackson.databind.JsonNode;
// import com.fasterxml.jackson.databind.ObjectMapper;
// import com.fasterxml.jackson.databind.node.ArrayNode;
// import com.fasterxml.jackson.databind.node.ObjectNode;

// import javax.imageio.ImageIO;
// import java.awt.image.BufferedImage;
// import java.nio.file.Files;
// import java.nio.file.Path;
// import java.nio.file.Paths;
// import java.nio.file.attribute.BasicFileAttributes;
// import java.time.Instant;
// import java.time.LocalDateTime;
// import java.time.ZoneId;
// import java.time.format.DateTimeFormatter;

// @RestController
// @RequestMapping("/api/photographer/photos")
// public class PhotosController {

// 	private final Path baseDirectory = Paths.get("C:/MyFolders/Thumbnails");
// 	private final ObjectMapper objectMapper = new ObjectMapper();

// 	@GetMapping("/all-content")
// 	public ResponseEntity<JsonNode> listFolderContents(@RequestParam String projectId,
// 			@RequestParam(value = "path", defaultValue = "") String path,
// 			@RequestParam(value = "page", defaultValue = "0") int page,
// 			@RequestParam(value = "size", defaultValue = "20") int size) throws IOException {

// 		Path folderPath = baseDirectory.resolve(path);

// 		if (!folderPath.startsWith(baseDirectory)) {
// 			return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
// 		}

// 		if (Files.exists(folderPath) && Files.isDirectory(folderPath)) {
// 			JsonNode pagedItems = listFilesPaginated(folderPath, page, size);
// 			return ResponseEntity.status(HttpStatus.OK).body(pagedItems);
// 		} else {
// 			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
// 		}
// 	}

// 	private JsonNode listFilesPaginated(Path root, int page, int size) throws IOException {
// 		ArrayNode filesArray = objectMapper.createArrayNode();

// 		if (root == null || !Files.isDirectory(root)) {
// 			throw new IllegalArgumentException("Path is not a valid directory: " + root);
// 		}

// 		try (Stream<Path> paths = Files.list(root)) {
// 			List<Path> filteredPaths = paths.collect(Collectors.toList());

// 			int start = Math.min(page * size, filteredPaths.size()); // start= Math.min(0 * 20,45)=Math.min(0,45)=0
// 			int end = Math.min(start + size, filteredPaths.size()); // end= Math.min(0 + 20,45)=Math.min(10,45)=20

// 			for (Path path : filteredPaths.subList(start, end)) {
// 				ObjectNode fileData = objectMapper.createObjectNode();
// 				if (Files.isDirectory(path)) {
// 					fileData.put("filename", root.relativize(path).toString());
// 					fileData.put("type", "folder");
// 					fileData.putNull("url");
// 				} else {
// 					// String filename = path.getFileName().toString();
// 					Path relativePath = baseDirectory.relativize(path);

// 					String fileUrl = "/photos/thumbnail/" + relativePath.toString().replace("\\", "/");

// 					BufferedImage image = ImageIO.read(path.toFile());
// 					if (image == null) {
// 						continue; // Skip non-image files
// 					}
// 					int width = image.getWidth();
// 					int height = image.getHeight();

// 					BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class); // interface
// 					Instant creationInstant = attrs.creationTime().toInstant();
// 					LocalDateTime creationDateTime = LocalDateTime.ofInstant(creationInstant, ZoneId.systemDefault());
// 					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
// 					String createdDate = creationDateTime.format(formatter);

// 					long fileSizeBytes = Files.size(path);
// 					String fileSize = formatFileSize(fileSizeBytes);

// 					fileData.put("filename", root.relativize(path).toString());
// 					fileData.put("type", "file");
// 					fileData.put("url", fileUrl);
// 					fileData.put("width", width);
// 					fileData.put("height", height);
// 					fileData.put("createdDate", createdDate);
// 					fileData.put("size", fileSize);
// 				}
// 				filesArray.add(fileData);
// 			}
// 		} catch (IOException e) {
// 			throw e;
// 		}
// 		return filesArray;
// 	}

// 	private String formatFileSize(long sizeInBytes) {
// 		if (sizeInBytes < 1024) {
// 			return sizeInBytes + " B";
// 		} else if (sizeInBytes < 1024 * 1024) {
// 			return (sizeInBytes / 1024) + " KB";
// 		} else if (sizeInBytes < 1024 * 1024 * 1024) {
// 			return (sizeInBytes / (1024 * 1024)) + " MB";
// 		} else {
// 			return (sizeInBytes / (1024 * 1024 * 1024)) + " GB";
// 		}
// 	}
// }
