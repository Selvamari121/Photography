package com.companyname.projectname.crm.controller;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.authentication.service.SecurityService;
import com.companyname.projectname.crm.dto.ScheduleDto;
import com.companyname.projectname.crm.dto.ScheduleExpiredDto;
import com.companyname.projectname.crm.model.ScheduleEntity;
import com.companyname.projectname.crm.service.ScheduleService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("api/photographer/schedule")
public class ScheduleController {

	@Autowired
	private SecurityService securityService;

	@Autowired
	private ScheduleService scheduleService;

	@PostMapping
	public ResponseEntity<Void> createSchedule(@Valid @RequestBody ScheduleEntity schedule) {
		scheduleService.createSchedule(schedule);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@GetMapping("/project/{projectId}")
	public ResponseEntity<List<ScheduleDto>> getAllSchedules(@PathVariable String projectId) {
		List<ScheduleDto> scheduleList = scheduleService.getAllSchedules(projectId);
		return ResponseEntity.status(HttpStatus.OK).body(scheduleList);
	}

	@GetMapping("/{scheduleId}")
	public ResponseEntity<ScheduleDto> getScheduleById(@PathVariable String scheduleId) {
		ScheduleDto scheduleData = scheduleService.getScheduleById(scheduleId);
		return ResponseEntity.status(HttpStatus.OK).body(scheduleData);
	}

	@PutMapping("/{scheduleId}")
	public ResponseEntity<Void> updateSchedule(@PathVariable String scheduleId,
			@Valid @RequestBody ScheduleEntity schedule) {
		scheduleService.updateSchedule(scheduleId, schedule);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@DeleteMapping("/{scheduleId}")
	public ResponseEntity<Void> deleteScheduleById(@PathVariable String scheduleId) {
		scheduleService.deleteScheduleById(scheduleId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}

	@GetMapping("/expired")
	public ResponseEntity<List<ScheduleExpiredDto>> getAllExpiredSchedule() {
		int photographerId = securityService.getPhotographerKey();
		List<ScheduleExpiredDto> scheduleList = scheduleService.getAllExpiredSchedule(photographerId);
		return ResponseEntity.status(HttpStatus.OK).body(scheduleList);
	}

	// @GetMapping("/payment-date")
	// public ResponseEntity<BigDecimal> getAmountByPaymentDate(@RequestParam LocalDateTime startDate,
	// 		@RequestParam LocalDateTime endDate) {
	// 	int photographerId = securityService.getPhotographerKey();
	// 	BigDecimal amount = scheduleService.getAmountByPaymentDate(startDate, endDate, photographerId);
	// 	return ResponseEntity.status(HttpStatus.OK).body(amount);
	// }

	// @GetMapping("/payment-duedate")
	// public ResponseEntity<BigDecimal> getAmountByDueDate(@RequestParam LocalDateTime startDate,
	// 		@RequestParam LocalDateTime endDate) {
	// 	int photographerId = securityService.getPhotographerKey();
	// 	BigDecimal amount = scheduleService.getAmountByDueDate(startDate, endDate, photographerId);
	// 	return ResponseEntity.status(HttpStatus.OK).body(amount);
	// }

	// @GetMapping("/total-paid-amount")
	// public ResponseEntity<BigDecimal> getTotalPaidAmount() {
	// 	int photographerId = securityService.getPhotographerKey();
	// 	BigDecimal amount = scheduleService.getTotalPaidAmount(photographerId);
	// 	return ResponseEntity.status(HttpStatus.OK).body(amount);
	// }

	// @GetMapping("/total-amount")
	// public ResponseEntity<BigDecimal> getTotalAmount() {
	// 	int photographerId = securityService.getPhotographerKey();
	// 	BigDecimal amount = scheduleService.getTotalAmount(photographerId);
	// 	return ResponseEntity.status(HttpStatus.OK).body(amount);
	// }
}
