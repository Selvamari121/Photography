package com.companyname.projectname.authentication.dto;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignupDto {
	@NotBlank(message = "Phone number cannot be blank")
	@Size(max = 10, message = "Phone number cannot exceed 10 characters")
	private String phoneNo;

	@NotBlank(message = "Email cannot be blank")
	@Size(max = 25, message = "Email cannot exceed 25 characters")
	@Email(message = "Please enter a valid email address")
	private String email;

	// TODO: Pattern check?
	@NotBlank(message = "Password cannot be blank")
	@Size(max = 255, message = "Password cannot exceed 255 characters")
	private String password;

	@NotBlank(message = "First name cannot be blank")
	@Size(max = 50, message = "First name cannot exceed 50 characters")
	@Column(name = "first_name")
	private String firstName;

	@NotBlank(message = "Last name cannot be blank")
	@Size(max = 50, message = "Last name cannot exceed 50 characters")
	@Column(name = "last_name")
	private String lastName;

	@NotBlank(message = "Company name cannot be blank")
	@Size(max = 50, message = "Company name cannot exceed 50 characters")
	private String companyName;

	@NotBlank(message = "Address line one cannot be blank")
	@Size(max = 100, message = "Address line one cannot exceed 100 characters")
	private String addressLine1;

	@Size(max = 100, message = "Address line two cannot exceed 100 characters")
	private String addressLine2;

	@NotBlank(message = "City cannot be blank")
	@Size(max = 25, message = "City cannot exceed 25 characters")
	private String city;

	@NotBlank(message = "State cannot be blank")
	@Size(max = 25, message = "State cannot exceed 25 characters")
	private String state;

	@NotBlank(message = "Country cannot be blank")
	@Size(max = 25, message = "Country cannot exceed 25 characters")
	private String country;

	@NotBlank(message = "Pin code cannot be blank")
	@Size(max = 6, message = "Pin code cannot exceed 6 characters")
	private String pinCode;

	// TODO: Pattern check?
	@NotBlank(message = "Pan number cannot be blank")
	@Size(max = 10, message = "Pan number cannot exceed 10 characters")
	private String panNo;

	// TODO: Pattern check?
	@NotBlank(message = "Aadhar number cannot be blank")
	@Size(max = 12, message = "Aadhar number cannot exceed 12 characters")
	private String aadharNo;

	// TODO: Pattern check?
	@Size(max = 15, message = "GST number cannot exceed 15 characters")
	private String gstNo;
}
