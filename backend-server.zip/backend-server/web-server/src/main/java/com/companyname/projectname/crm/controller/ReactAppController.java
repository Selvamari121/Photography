package com.companyname.projectname.crm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ReactAppController {

	@RequestMapping(value = {"/photographer/**", "/customer/**"})
	public String redirect() {
		return "/index.html";
	}
}