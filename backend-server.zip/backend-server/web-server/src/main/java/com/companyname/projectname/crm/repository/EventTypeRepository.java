package com.companyname.projectname.crm.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.companyname.projectname.crm.dto.EventTypeDto;
import com.companyname.projectname.crm.model.EventTypeEntity;

public interface EventTypeRepository extends JpaRepository<EventTypeEntity, Integer> {

	@Query("SELECT new com.companyname.projectname.crm.dto.EventTypeDto(e.eventTypeId, e.name, e.description, p.projectTypeId, p.name as projectTypeName) "
			+ "FROM EventTypeEntity e JOIN ProjectTypeEntity p ON p.projectTypeKey = e.projectTypeKey ")
	List<EventTypeDto> findAllEventType();

	@Query("SELECT new com.companyname.projectname.crm.dto.EventTypeDto(e.eventTypeId, e.name, e.description, p.projectTypeId, p.name as projectTypeName) "
			+ "FROM EventTypeEntity e JOIN ProjectTypeEntity p ON p.projectTypeKey = e.projectTypeKey "
			+ "WHERE e.eventTypeKey = :eventTypeKey ")
	Optional<EventTypeDto> findByEventTypeKey(@Param("eventTypeKey") int eventTypeKey);
}
