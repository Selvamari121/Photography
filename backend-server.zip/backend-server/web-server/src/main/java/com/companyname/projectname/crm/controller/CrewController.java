package com.companyname.projectname.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.authentication.service.SecurityService;
import com.companyname.projectname.crm.dto.CrewDto;
import com.companyname.projectname.crm.model.CrewEntity;
import com.companyname.projectname.crm.service.CrewService;
import com.companyname.projectname.exception.ValidationException;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/photographer/crews")
public class CrewController {
	@Autowired
	private CrewService crewService;

	@Autowired
	private SecurityService securityService;

	@PostMapping
	public ResponseEntity<Void> createCrew(@Valid @RequestBody CrewEntity crew) {
		if (crew.getRoleId() == null || crew.getRoleId().trim().isEmpty()) {
			throw new ValidationException("Role cannot be blank");
		}
		crewService.createCrew(crew);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@GetMapping
	public ResponseEntity<List<CrewDto>> getAllCrews() {
		int photographerKey = securityService.getPhotographerKey();
		List<CrewDto> crewList = crewService.getAllCrews(photographerKey);
		return ResponseEntity.status(HttpStatus.OK).body(crewList);
	}

	@GetMapping("/{crewId}")
	public ResponseEntity<CrewDto> getCrewById(@PathVariable String crewId) {
		CrewDto crewData = crewService.getCrewById(crewId);
		return ResponseEntity.status(HttpStatus.OK).body(crewData);
	}

	@PutMapping("/{crewId}")
	public ResponseEntity<Void> updateCrew(@PathVariable String crewId, @Valid @RequestBody CrewEntity crewEntity) {
		crewService.updateCrew(crewId, crewEntity);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@DeleteMapping("/{crewId}")
	public ResponseEntity<Void> deleteCrewById(@PathVariable String crewId) {
		crewService.deleteCrewById(crewId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}
}
