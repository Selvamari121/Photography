package com.companyname.projectname.crm.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.companyname.projectname.crm.dto.PlanCustomerDto;
import com.companyname.projectname.crm.model.PlanCustomerEntity;

public interface PlanCustomerRepository extends JpaRepository<PlanCustomerEntity, Integer> {
	@Query("SELECT new com.companyname.projectname.crm.dto.PlanCustomerDto(p.planCustomerId, p.name, p.cost, p.features, p.description) "
			+ "FROM PlanCustomerEntity p ")
	List<PlanCustomerDto> findAllPlanCustomer();

	@Query("SELECT new com.companyname.projectname.crm.dto.PlanCustomerDto(p.planCustomerId, p.name, p.cost, p.features, p.description) "
			+ "FROM PlanCustomerEntity p WHERE p.planCustomerKey = :planCustomerKey")
	Optional<PlanCustomerDto> findByPlanCustomerKey(@Param("planCustomerKey") int planCustomerKey);

}
