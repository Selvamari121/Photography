package com.companyname.projectname.crm.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "project_type")
public class ProjectTypeEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_prtid")
	private int projectTypeKey;

	@Column(name = "prtid")
	private String projectTypeId;

	@NotBlank(message = "Name cannot be blank")
	@Size(max = 255, message = "Name cannot exceed 255 characters")
	@Column(name = "name")
	private String name;

	@NotBlank(message = "Description cannot be blank")
	@Size(max = 200, message = "Description cannot exceed 200 characters")
	@Column(name = "description")
	private String description;
}
