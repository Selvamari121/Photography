package com.companyname.projectname.crm.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "event_type")
public class EventTypeEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_evtid")
	private int eventTypeKey;

	@Column(name = "evtid")
	private String eventTypeId;

	@Column(name = "fk_prtid")
	private int projectTypeKey;

	@NotBlank(message = "Name cannot be blank")
	@Size(max = 200, message = "Name cannot exceed 200 characters")
	@Column(name = "name")
	private String name;

	@NotBlank(message = "Event description cannot be blank")
	@Size(max = 200, message = "Event description cannot exceed 200 characters")
	@Column(name = "description")
	private String description;

	@Transient
	private String projectTypeId;
}
