package com.companyname.projectname.crm.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "plan_customer")
public class PlanCustomerEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_plcuid")
	private int planCustomerKey;

	@Column(name = "plcuid")
	private String planCustomerId;

	@NotBlank(message = "Name cannot be blank")
	@Size(max = 50, message = "Name cannot exceed 50 characters")
	@Column(name = "name")
	private String name;

	@Min(value = 1, message = "Cost must be greater than zero")
	@Column(name = "cost")
	private int cost;

	@NotBlank(message = "Features cannot be blank")
	@Size(max = 200, message = "Features cannot exceed 200 characters")
	@Column(name = "features")
	private String features;

	@NotBlank(message = "Description cannot be blank")
	@Size(max = 250, message = "Description cannot exceed 250 characters")
	@Column(name = "description")
	private String description;
}
