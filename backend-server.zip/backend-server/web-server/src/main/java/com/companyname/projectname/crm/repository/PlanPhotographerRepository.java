package com.companyname.projectname.crm.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.companyname.projectname.crm.dto.PlanPhotographerDto;
import com.companyname.projectname.crm.model.PlanPhotographerEntity;

public interface PlanPhotographerRepository extends JpaRepository<PlanPhotographerEntity, Integer> {

	@Query("SELECT new com.companyname.projectname.crm.dto.PlanPhotographerDto(p.planPhotographerId, p.name, p.cost, p.features, p.description) "
			+ "FROM PlanPhotographerEntity p ")
	List<PlanPhotographerDto> findAllPlanPhotographer();

	@Query("SELECT new com.companyname.projectname.crm.dto.PlanPhotographerDto(p.planPhotographerId, p.name, p.cost, p.features, p.description) "
			+ "FROM PlanPhotographerEntity p WHERE p.planPhotographerKey = :planPhotographerKey")
	Optional<PlanPhotographerDto> findByPlanPhotographerKey(@Param("planPhotographerKey") int planPhotographerKey);

}
