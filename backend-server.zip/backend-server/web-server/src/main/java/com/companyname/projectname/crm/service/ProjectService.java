package com.companyname.projectname.crm.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyname.projectname.authentication.service.SecurityService;
import com.companyname.projectname.crm.dto.ProjectDto;
import com.companyname.projectname.crm.model.ProjectEntity;
import com.companyname.projectname.crm.repository.ProjectRepository;
import com.companyname.projectname.exception.ItemNotFoundException;
import com.companyname.projectname.util.KeyIdConversion;

@Service
public class ProjectService {
	@Autowired
	ProjectRepository projectRepository;

	@Autowired
	private KeyIdConversion conversion;

	@Autowired
	private SecurityService securityService;

	public void createProject(ProjectEntity project) {
		int photographerKey = securityService.getPhotographerKey();
		int projectTypeKey = conversion.IdToKeyConversion(project.getProjectTypeId(), 3);
		ProjectEntity projectEntity = new ProjectEntity();
		projectEntity.setPhotographerKey(photographerKey);
		projectEntity.setProjectName(project.getProjectName());
		projectEntity.setProjectTypeKey(projectTypeKey);
		projectEntity.setCreateDate(LocalDate.now());
		projectRepository.save(projectEntity);
	}

	public List<ProjectDto> getAllProject(int photographerId) {
		return projectRepository.findAllProjects(photographerId);
	}

	public ProjectDto getProjectById(String projectId) {
		int projectKey = conversion.IdToKeyConversion(projectId, 2);
		return projectRepository.findByProjectKey(projectKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public void updateProject(String projectId, ProjectEntity updatedProject) {
		int projectKey = conversion.IdToKeyConversion(projectId, 2);
		ProjectEntity existingProject = projectRepository.findById(projectKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));

		int projectTypeKey = conversion.IdToKeyConversion(updatedProject.getProjectTypeId(), 3);
		existingProject.setProjectName(updatedProject.getProjectName());
		existingProject.setProjectTypeKey(projectTypeKey);
		projectRepository.save(existingProject);
	}

	public void deleteProjectById(String projectId) {
		int projectKey = conversion.IdToKeyConversion(projectId, 2);
		if (!projectRepository.existsById(projectKey)) {
			throw new ItemNotFoundException("Item not found. Please try again.");
		}
		projectRepository.deleteById(projectKey);
	}
}
