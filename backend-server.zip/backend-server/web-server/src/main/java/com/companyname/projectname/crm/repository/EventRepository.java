
package com.companyname.projectname.crm.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.companyname.projectname.crm.dto.EventDto;
import com.companyname.projectname.crm.dto.EventMonthDto;
import com.companyname.projectname.crm.model.EventEntity;

public interface EventRepository extends JpaRepository<EventEntity, Integer> {

	@Query("SELECT new com.companyname.projectname.crm.dto.EventDto(e.eventId, p.projectName, e.fromDateTime, e.toDateTime, t.eventTypeId, e.description, e.addressLink, e.addressLine1, e.addressLine2, e.city, e.state, e.country, e.pinCode, t.name as eventType) "
			+ "FROM EventEntity e " + "JOIN ProjectEntity p ON e.projectKey = p.projectKey "
			+ "JOIN EventTypeEntity t ON e.eventTypeKey = t.eventTypeKey " + "WHERE e.eventKey = :eventKey ")
	Optional<EventDto> findByEventKey(@Param("eventKey") int eventKey);

	@Query("SELECT new com.companyname.projectname.crm.dto.EventDto(e.eventId, p.projectName, e.fromDateTime, e.toDateTime, t.eventTypeId, e.description, e.addressLink, e.addressLine1, e.addressLine2, e.city, e.state, e.country, e.pinCode, t.name as eventType) "
			+ "FROM EventEntity e " + "JOIN ProjectEntity p ON e.projectKey = p.projectKey "
			+ "JOIN EventTypeEntity t ON e.eventTypeKey = t.eventTypeKey " + "WHERE e.projectKey = :projectKey ")
	List<EventDto> findAllByProjectKey(@Param("projectKey") int projectKey);

	@Query("SELECT new com.companyname.projectname.crm.dto.EventMonthDto(e.eventId, e.fromDateTime, e.toDateTime, t.eventTypeId, t.description as eventType) "
			+ "FROM EventEntity e " + "JOIN EventTypeEntity t ON e.eventTypeKey = t.eventTypeKey "
			+ "JOIN ProjectEntity p ON e.projectKey = p.projectKey "
			+ "WHERE p.photographerKey = :photographerKey AND e.fromDateTime BETWEEN :startDate AND :endDate ")
	List<EventMonthDto> findByYearAndMonth(@Param("startDate") LocalDateTime startDate,
			@Param("endDate") LocalDateTime endDate, @Param("photographerKey") int photographerKey);

	@Query(value = "SELECT DISTINCT DATE(e.from_time) " + "FROM event e " + "JOIN project p ON e.fk_prid = p.pk_prid "
			+ "WHERE p.fk_phid = :photographerKey "
			+ "AND e.from_time BETWEEN :startOfYear AND :endOfYear ", nativeQuery = true)
	List<java.sql.Date> findDistinctDatesByYear(@Param("startOfYear") LocalDateTime startOfYear,
			@Param("endOfYear") LocalDateTime endOfYear, @Param("photographerKey") int photographerKey);

	@Query("SELECT new com.companyname.projectname.crm.dto.EventDto(e.eventId, p.projectName, e.fromDateTime, e.toDateTime, t.eventTypeId, e.description, e.addressLink, e.addressLine1, e.addressLine2, e.city, e.state, e.country, e.pinCode, t.name as eventType) "
			+ "FROM EventEntity e " + "JOIN ProjectEntity p ON e.projectKey = p.projectKey "
			+ "JOIN EventTypeEntity t ON e.eventTypeKey = t.eventTypeKey "
			+ "WHERE p.photographerKey = :photographerKey " + "AND e.fromDateTime BETWEEN :startDate AND :endDate ")
	List<EventDto> findByDateRange(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate,
			@Param("photographerKey") int photographerKey);
}
