package com.companyname.projectname.crm.dto;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class ProjectDto {
	private String projectId;

	private String projectName;

	private String projectTypeId;

	private LocalDate createDate;

	private String projectType;
}
