package com.companyname.projectname.authentication.respository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.companyname.projectname.authentication.model.UserEntity;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, String> {

	@Query("SELECT u FROM UserEntity u WHERE u.phoneNo = :phoneNo ")
	Optional<UserEntity> findByPhoneNo(@Param("phoneNo") String phoneNo);

	@Query("SELECT u FROM UserEntity u WHERE u.email = :email ")
	Optional<UserEntity> findByEmail(@Param("email") String email);

	@Query("SELECT u.photographerKey FROM UserEntity u WHERE u.email = :email")
	Integer findIdByMail(@Param("email") String email);

	@Query("SELECT u.photographerKey FROM UserEntity u WHERE u.phoneNo = :phoneNo ")
	Integer findIdByMobileNo(@Param("phoneNo") String phoneNo);
}
