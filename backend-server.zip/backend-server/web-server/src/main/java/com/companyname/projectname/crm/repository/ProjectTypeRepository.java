package com.companyname.projectname.crm.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.companyname.projectname.crm.dto.ProjectTypeDto;
import com.companyname.projectname.crm.model.ProjectTypeEntity;

public interface ProjectTypeRepository extends JpaRepository<ProjectTypeEntity, Integer> {

	@Query("SELECT new com.companyname.projectname.crm.dto.ProjectTypeDto(p.projectTypeId, p.name, p.description) "
			+ "FROM ProjectTypeEntity p ")
	List<ProjectTypeDto> findAllProjectType();

	@Query("SELECT new com.companyname.projectname.crm.dto.ProjectTypeDto(p.projectTypeId, p.name, p.description) "
			+ "FROM ProjectTypeEntity p WHERE p.projectTypeKey = :projectTypeKey")
	Optional<ProjectTypeDto> findByProjectTypeKey(@Param("projectTypeKey") int projectTypeKey);

}