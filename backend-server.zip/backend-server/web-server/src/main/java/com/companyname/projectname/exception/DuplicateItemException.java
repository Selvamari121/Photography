package com.companyname.projectname.exception;

public class DuplicateItemException extends RuntimeException {
	public DuplicateItemException(String message) {
		super(message);
	}
}