package com.companyname.projectname.crm.service;

import org.springframework.stereotype.Service;

@Service
public class CustomerService {

}
