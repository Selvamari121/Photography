package com.companyname.projectname.crm.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Getter
@Setter
@Table(name = "customer")
public class CustomerEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_cuid")
	private int customerKey;

	@Column(name = "cuid")
	private String customerId;

	@NotBlank(message = "First name cannot be blank")
	@Size(max = 50, message = "First name cannot exceed 50 characters")
	@Column(name = "first_name")
	private String firstName;

	@NotBlank(message = "Last name cannot be blank")
	@Size(max = 50, message = "Last name cannot exceed 50 characters")
	@Column(name = "last_name")
	private String lastName;

	// TODO: Pattern check?
	@NotNull(message = "date of birth cannot be null")
	@Column(name = "dob")
	private LocalDate dob;

	@NotBlank(message = "Gender cannot be blank")
	@Size(max = 1, message = "Gender cannot exceed 1 characters")
	@Column(name = "gender")
	private String gender;

	@NotBlank(message = "Address line one cannot be blank")
	@Size(max = 100, message = "Address line one cannot exceed 100 characters")
	@Column(name = "address_line1")
	private String addressLine1;

	@Size(max = 100, message = "Address line two cannot exceed 100 characters")
	@Column(name = "address_line2")
	private String addressLine2;

	@NotBlank(message = "City cannot be blank")
	@Size(max = 25, message = "City cannot exceed 25 characters")
	@Column(name = "city")
	private String city;

	@NotBlank(message = "State cannot be blank")
	@Size(max = 25, message = "State cannot exceed 25 characters")
	@Column(name = "state")
	private String state;

	@NotBlank(message = "Country cannot be blank")
	@Size(max = 25, message = "Country cannot exceed 25 characters")
	@Column(name = "country")
	private String country;

	@NotBlank(message = "Pin code cannot be blank")
	@Size(max = 6, message = "Pin code cannot exceed 6 characters")
	@Column(name = "pincode")
	private String pinCode;
}
