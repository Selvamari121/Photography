package com.companyname.projectname.authentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.authentication.dto.LoginDto;
import com.companyname.projectname.authentication.dto.SignupDto;
import com.companyname.projectname.authentication.service.JwtService;
import com.companyname.projectname.authentication.service.MyUserDetailsService;
import com.companyname.projectname.authentication.service.UserService;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/photographer")
public class UserController {

	@Autowired
	private JwtService jwtService;

	@Autowired
	private UserService userService;

	@Autowired
	ApplicationContext context;

	@PostMapping("/signup")
	public ResponseEntity<Void> signupUser(@Valid @RequestBody SignupDto user) {
		userService.signupUser(user);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@Valid @RequestBody LoginDto loginUser, HttpServletResponse response)
			throws Exception {
		String jwt = userService.authenticateUser(loginUser);

		Cookie cookie = new Cookie("photographerToken", jwt);
		cookie.setHttpOnly(true);
		cookie.setSecure(true);
		cookie.setPath("/");
		response.addCookie(cookie);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@PostMapping("/logout")
	public ResponseEntity<?> logout(HttpServletResponse response) {
		Cookie cookie = new Cookie("photographerToken", null);
		cookie.setHttpOnly(true);
		cookie.setSecure(true);
		cookie.setPath("/");
		cookie.setMaxAge(0); // Immediately invalidate the cookie
		response.addCookie(cookie);

		// clear the authentication from the security context
		SecurityContextHolder.clearContext();
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	// TODO : Check the validation of this functionality later.
	@GetMapping("/auth/check")
	public ResponseEntity<?> checkAuthentication(HttpServletRequest request) {
		String jwtToken = null;
		Cookie[] cookies = request.getCookies();

		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("photographerToken")) {
					jwtToken = cookie.getValue();
					break;
				}
			}
		}

		if (jwtToken == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid attempt. Please try again");
		}

		try {
			// Check if the token is valid and not expired
			String username = jwtService.extractUserName(jwtToken);
			UserDetails userDetails = context.getBean(MyUserDetailsService.class).loadUserByUsername(username);
			if (username != null && jwtService.validateToken(jwtToken, userDetails)) {
				return ResponseEntity.status(HttpStatus.OK).build();
			} else {
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid or expired token");
			}
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication failed");
		}
	}
}
