package com.companyname.projectname.crm.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "photographer")
public class PhotographerEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_phid")
	private int photographerKey;

	@Column(name = "phid")
	private String photographerId;

	@NotBlank(message = "First name cannot be blank")
	@Size(max = 50, message = "First name cannot exceed 50 characters")
	@Column(name = "first_name")
	private String firstName;

	@NotBlank(message = "Last name cannot be blank")
	@Size(max = 50, message = "Last name cannot exceed 50 characters")
	@Column(name = "last_name")
	private String lastName;

	@NotBlank(message = "Company name cannot be blank")
	@Size(max = 50, message = "Company name cannot exceed 50 characters")
	@Column(name = "company_name")
	private String companyName;

	@NotBlank(message = "Address line one cannot be blank")
	@Size(max = 100, message = "Address line one cannot exceed 100 characters")
	@Column(name = "address_line1")
	private String addressLine1;

	@Size(max = 100, message = "Address line two cannot exceed 100 characters")
	@Column(name = "address_line2")
	private String addressLine2;

	@NotBlank(message = "City cannot be blank")
	@Size(max = 25, message = "City cannot exceed 25 characters")
	@Column(name = "city")
	private String city;

	@NotBlank(message = "State cannot be blank")
	@Size(max = 25, message = "State cannot exceed 25 characters")
	@Column(name = "state")
	private String state;

	@NotBlank(message = "Country cannot be blank")
	@Size(max = 25, message = "Country cannot exceed 25 characters")
	@Column(name = "country")
	private String country;

	@NotBlank(message = "Pin code cannot be blank")
	@Size(max = 6, message = "Pin code cannot exceed 6 characters")
	@Column(name = "pincode")
	private String pinCode;

	// TODO: Pattern check?
	@NotBlank(message = "Pan number cannot be blank")
	@Size(max = 10, message = "Pan number cannot exceed 10 characters")
	@Column(name = "pan_number")
	private String panNo;

	// TODO: Pattern check?
	@NotBlank(message = "Aadhar number cannot be blank")
	@Size(max = 12, message = "Aadhar number cannot exceed 12 characters")
	@Column(name = "aadhar_number")
	private String aadharNo;

	// TODO: Pattern check?
	@Size(max = 15, message = "GST number cannot exceed 15 characters")
	@Column(name = "gst_number")
	private String gstNo;

	@Column(name = "fk_plphid")
	private Integer planPhotographerKey;
}
