package com.companyname.projectname.crm.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class EventDto {
	private String eventId;

	private String projectName;

	private LocalDateTime fromDateTime;

	private LocalDateTime toDateTime;

	private String eventTypeId;

	private String description;

	private String addressLink;

	private String addressLine1;

	private String addressLine2;

	private String city;

	private String state;

	private String country;

	private String pinCode;

	private String eventType;
}
