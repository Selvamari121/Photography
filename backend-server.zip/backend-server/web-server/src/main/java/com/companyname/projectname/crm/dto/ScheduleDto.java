package com.companyname.projectname.crm.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class ScheduleDto {
	private String scheduleId;

	private BigDecimal scheduleAmount;

	private LocalDateTime paymentDueDate;

	private Boolean isPaid;

	private LocalDateTime paymentDate;
}
