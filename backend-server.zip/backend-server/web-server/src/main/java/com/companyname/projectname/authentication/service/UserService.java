package com.companyname.projectname.authentication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.security.core.AuthenticationException;

import com.companyname.projectname.authentication.dto.LoginDto;
import com.companyname.projectname.authentication.dto.SignupDto;
import com.companyname.projectname.authentication.model.UserEntity;
import com.companyname.projectname.authentication.respository.UserRepository;
import com.companyname.projectname.crm.model.PhotographerEntity;
import com.companyname.projectname.crm.repository.PhotographerRepository;
import com.companyname.projectname.exception.DuplicateItemException;

import jakarta.transaction.Transactional;

@Service
public class UserService {

	@Autowired
	private JwtService jwtService;

	@Autowired
	AuthenticationManager authManager;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PhotographerRepository photographerRepository;

	private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(4);

	@Transactional
	public void signupUser(SignupDto signupRequest) {

		if (userRepository.findByEmail(signupRequest.getEmail()).isPresent()) {
			throw new DuplicateItemException("Email is already taken.");
		}
		if (userRepository.findByPhoneNo(signupRequest.getPhoneNo()).isPresent()) {
			throw new DuplicateItemException("Mobile number is already taken.");
		}

		PhotographerEntity photographer = new PhotographerEntity();
		photographer.setFirstName(signupRequest.getFirstName());
		photographer.setLastName(signupRequest.getLastName());
		photographer.setCompanyName(signupRequest.getCompanyName());
		photographer.setAddressLine1(signupRequest.getAddressLine1());
		photographer.setAddressLine2(signupRequest.getAddressLine2());
		photographer.setCity(signupRequest.getCity());
		photographer.setState(signupRequest.getState());
		photographer.setCountry(signupRequest.getCountry());
		photographer.setPinCode(signupRequest.getPinCode());
		photographer.setPanNo(signupRequest.getPanNo());
		photographer.setAadharNo(signupRequest.getAadharNo());
		photographer.setGstNo(signupRequest.getGstNo());
		PhotographerEntity SavedPhotographer = photographerRepository.save(photographer);

		UserEntity user = new UserEntity();
		user.setPassword(encoder.encode(signupRequest.getPassword()));
		user.setPhoneNo(signupRequest.getPhoneNo());
		user.setEmail(signupRequest.getEmail());
		user.setActive(true);
		user.setType("PH");
		user.setEmail(signupRequest.getEmail());
		user.setPhotographerKey(SavedPhotographer.getPhotographerKey());
		userRepository.save(user);
	}

	public String authenticateUser(LoginDto loginUser) throws AuthenticationException {
		Authentication authentication = authManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginUser.getUserName(), loginUser.getPassword()));
		if (authentication.isAuthenticated()) {
			return jwtService.generateToken(loginUser.getUserName());
		} else {
			throw new BadCredentialsException("Invalid username or password");
		}
	}
}
