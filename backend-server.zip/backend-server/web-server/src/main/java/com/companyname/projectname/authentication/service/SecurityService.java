package com.companyname.projectname.authentication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.companyname.projectname.authentication.respository.UserRepository;
import com.companyname.projectname.exception.UnauthorizedException;

@Service
public class SecurityService {
	@Autowired
	private UserRepository userRepository;

	private static final String PHONE_REGEX = "^\\d{10}$";
	private static final String EMAIL_REGEX = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";

	public int getPhotographerKey() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null || !authentication.isAuthenticated()) {
			throw new UnauthorizedException("User is not authenticated");
		}

		Object principal = authentication.getPrincipal();
		if (principal instanceof UserDetails) {
			String userName = ((UserDetails) principal).getUsername();

			int photographerKey = 0;
			if (userName.matches(EMAIL_REGEX)) {
				photographerKey = userRepository.findIdByMail(userName);
			} else if (userName.matches(PHONE_REGEX)) {
				photographerKey = userRepository.findIdByMobileNo(userName);
			}

			if (photographerKey == 0) {
				throw new UnauthorizedException("Invalid. Please try again.");
			}
			return photographerKey;
		} else {
			return 0;
		}
	}
}
