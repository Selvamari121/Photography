package com.companyname.projectname.crm.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "payment_schedule")
public class ScheduleEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_schid")
	private int scheduleKey;

	@Column(name = "schid")
	private String scheduleId;

	@Column(name = "fk_prid")
	private int projectKey;

	@NotNull(message = "Amount cannot be null")
	@Positive(message = "Amount must be greater than zero")
	@Column(name = "amount")
	private BigDecimal scheduleAmount;

	@NotNull(message = "Payment due date cannot be null")
	@Column(name = "due_date")
	private LocalDateTime paymentDueDate;

	@Column(name = "is_paid")
	private Boolean isPaid;

	@Column(name = "pay_date")
	private LocalDateTime paymentDate;

	@Transient
	private String projectId;

}