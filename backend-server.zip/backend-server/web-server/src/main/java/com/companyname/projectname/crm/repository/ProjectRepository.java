package com.companyname.projectname.crm.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.companyname.projectname.crm.model.ProjectEntity;
import com.companyname.projectname.crm.dto.ProjectDto;

@Repository
public interface ProjectRepository extends JpaRepository<ProjectEntity, Integer> {
	@Query("SELECT new com.companyname.projectname.crm.dto.ProjectDto(p.projectId, p.projectName, t.projectTypeId, p.createDate, t.name as projectType) "
			+ "FROM ProjectEntity p " + "JOIN ProjectTypeEntity t ON p.projectTypeKey = t.projectTypeKey "
			+ "WHERE p.projectKey = :projectKey ")
	Optional<ProjectDto> findByProjectKey(@Param("projectKey") int projectKey);

	@Query("SELECT new com.companyname.projectname.crm.dto.ProjectDto(p.projectId, p.projectName, t.projectTypeId, p.createDate, t.name as projectType) "
			+ "FROM ProjectEntity p " + "JOIN ProjectTypeEntity t ON p.projectTypeKey = t.projectTypeKey "
			+ "WHERE p.photographerKey = :photographerKey")
	List<ProjectDto> findAllProjects(@Param("photographerKey") int photographerKey);
}
