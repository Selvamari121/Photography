package com.companyname.projectname.crm.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.companyname.projectname.crm.dto.PhotographerDto;
import com.companyname.projectname.crm.model.PhotographerEntity;

@Repository
public interface PhotographerRepository extends JpaRepository<PhotographerEntity, Integer> {

	@Query("SELECT p.firstName FROM PhotographerEntity p WHERE p.photographerKey = :photographerKey ")
	Optional<String> findNameByKey(@Param("photographerKey") int photographerKey);

	@Query("SELECT new com.companyname.projectname.crm.dto.PhotographerDto(p.firstName, p.lastName, p.companyName, p.addressLine1, p.addressLine2, p.city, p.state, p.country, p.pinCode, p.panNo, p.aadharNo, p.gstNo) "
			+ "FROM PhotographerEntity p " + "WHERE p.photographerKey = :photographerKey ")
	Optional<PhotographerDto> findPhotographerByKey(@Param("photographerKey") int photographerKey);
}
