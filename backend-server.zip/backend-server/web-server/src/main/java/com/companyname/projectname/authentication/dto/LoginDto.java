package com.companyname.projectname.authentication.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class LoginDto {
	@NotBlank(message = "User name cannot be blank")
	private String userName;

	@NotBlank(message = "Password cannot be blank")
	private String password;
}
