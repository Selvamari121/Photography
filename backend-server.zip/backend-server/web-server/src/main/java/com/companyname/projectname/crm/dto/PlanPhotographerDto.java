package com.companyname.projectname.crm.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class PlanPhotographerDto {
	private String planPhotographerId;

	private String name;

	private int cost;

	private String features;

	private String description;
}
