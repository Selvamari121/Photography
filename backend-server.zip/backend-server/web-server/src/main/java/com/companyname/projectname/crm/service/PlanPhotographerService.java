package com.companyname.projectname.crm.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyname.projectname.crm.dto.PlanPhotographerDto;
import com.companyname.projectname.crm.model.PlanPhotographerEntity;
import com.companyname.projectname.crm.repository.PlanPhotographerRepository;
import com.companyname.projectname.exception.ItemNotFoundException;
import com.companyname.projectname.util.KeyIdConversion;

@Service
public class PlanPhotographerService {
	@Autowired
	private PlanPhotographerRepository planPhotographerRepository;

	@Autowired
	private KeyIdConversion conversion;

	public void createPlanPhotographer(PlanPhotographerEntity planPhotographers) {
		planPhotographerRepository.save(planPhotographers);
	}

	public List<PlanPhotographerDto> getAllPlanPhotographers() {
		return planPhotographerRepository.findAllPlanPhotographer();
	}

	public PlanPhotographerDto getPlanPhotographerById(String planPhotographerId) {
		int planPhotographerKey = conversion.IdToKeyConversion(planPhotographerId, 3);
		return planPhotographerRepository.findByPlanPhotographerKey(planPhotographerKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public void updatePlanPhotographer(String planPhotographerId, PlanPhotographerEntity updatedPlanCustomer) {
		int planPhotographerKey = conversion.IdToKeyConversion(planPhotographerId, 3);
		PlanPhotographerEntity existingPlanPhotographer = planPhotographerRepository.findById(planPhotographerKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
		existingPlanPhotographer.setName(updatedPlanCustomer.getName());
		existingPlanPhotographer.setCost(updatedPlanCustomer.getCost());
		existingPlanPhotographer.setFeatures(updatedPlanCustomer.getFeatures());
		existingPlanPhotographer.setDescription(updatedPlanCustomer.getDescription());
		planPhotographerRepository.save(existingPlanPhotographer);
	}

	public void deletePlanPhotographerById(String planPhotographerId) {
		int planPhotographerKey = conversion.IdToKeyConversion(planPhotographerId, 3);
		if (!planPhotographerRepository.existsById(planPhotographerKey)) {
			throw new ItemNotFoundException("Item not found. Please try again.");
		}
		planPhotographerRepository.deleteById(planPhotographerKey);
	}
}
