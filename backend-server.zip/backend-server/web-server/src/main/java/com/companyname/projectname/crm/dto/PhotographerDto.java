package com.companyname.projectname.crm.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class PhotographerDto {
	private String firstName;

	private String lastName;

	private String companyName;

	private String addressLine1;

	private String addressLine2;

	private String city;

	private String state;

	private String country;

	private String pinCode;

	private String panNo;

	private String aadharNo;

	private String gstNo;

}
