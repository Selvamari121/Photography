package com.companyname.projectname.crm.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.crm.dto.PlanCustomerDto;
import com.companyname.projectname.crm.model.PlanCustomerEntity;
import com.companyname.projectname.crm.service.PlanCustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/photographer/plan-customer")
public class PlanCustomerController {
	@Autowired
	private PlanCustomerService planCustomerService;

	@PostMapping
	public ResponseEntity<Void> createPlanCustomer(@Valid @RequestBody PlanCustomerEntity planCustomers) {
		planCustomerService.createPlanCustomer(planCustomers);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@GetMapping
	public ResponseEntity<List<PlanCustomerDto>> getAllPlanCustomers() {
		List<PlanCustomerDto> planCustomerList = planCustomerService.getAllPlanCustomers();
		return ResponseEntity.status(HttpStatus.OK).body(planCustomerList);
	}

	@GetMapping("/{planCustomerId}")
	public ResponseEntity<PlanCustomerDto> getPlanCustomerById(@PathVariable String planCustomerId) {
		PlanCustomerDto planCustomerData = planCustomerService.getPlanCustomerById(planCustomerId);
		return ResponseEntity.status(HttpStatus.OK).body(planCustomerData);
	}

	@PutMapping("/{planCustomerId}")
	public ResponseEntity<Void> updatePlanCustomer(@PathVariable String planCustomerId,
			@Valid @RequestBody PlanCustomerEntity planCustomers) {
		planCustomerService.updatePlanCustomer(planCustomerId, planCustomers);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@DeleteMapping("/{planCustomerId}")
	public ResponseEntity<Void> deletePlanCustomerById(@PathVariable String planCustomerId) {
		planCustomerService.deletePlanCustomerById(planCustomerId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}
}
