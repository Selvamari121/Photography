package com.companyname.projectname.crm.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.companyname.projectname.crm.model.CrewEntity;
import com.companyname.projectname.crm.dto.CrewDto;

public interface CrewRepository extends JpaRepository<CrewEntity, Integer> {

	@Query("SELECT new com.companyname.projectname.crm.dto.CrewDto(c.crewId, c.firstName, c.lastName, r.roleId, r.name as roleName) "
			+ "FROM CrewEntity c JOIN RoleEntity r ON r.roleKey = c.roleKey " + "WHERE c.crewKey = :crewKey ")
	Optional<CrewDto> findByCrewKey(@Param("crewKey") int crewKey);

	@Query("SELECT new com.companyname.projectname.crm.dto.CrewDto(c.crewId, c.firstName, c.lastName, r.roleId, r.name as roleName) "
			+ "FROM CrewEntity c JOIN RoleEntity r ON r.roleKey = c.roleKey "
			+ "WHERE c.photographerKey = :photographerKey ")
	List<CrewDto> findAllCrew(@Param("photographerKey") int photographerKey);
}