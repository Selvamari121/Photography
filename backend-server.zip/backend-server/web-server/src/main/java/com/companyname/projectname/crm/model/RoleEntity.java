package com.companyname.projectname.crm.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "role")
public class RoleEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_rid")
	private int roleKey;

	@Column(name = "rid")
	private String roleId;

	@NotBlank(message = "Role name cannot be blank")
	@Size(max = 25, message = "Role name cannot exceed 25 characters")
	@Column(name = "name")
	private String name;

	@NotBlank(message = "Role description cannot be blank")
	@Size(max = 200, message = "Role description cannot exceed 200 characters")
	@Column(name = "description")
	private String description;
}
