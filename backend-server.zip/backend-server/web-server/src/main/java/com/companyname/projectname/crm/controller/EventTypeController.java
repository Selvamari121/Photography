package com.companyname.projectname.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.crm.dto.EventTypeDto;
import com.companyname.projectname.crm.model.EventTypeEntity;
import com.companyname.projectname.crm.service.EventTypeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("api/photographer/event-type")
public class EventTypeController {

	@Autowired
	private EventTypeService eventTypeService;

	@PostMapping
	public ResponseEntity<Void> createEventType(@Valid @RequestBody EventTypeEntity eventTypes) {
		eventTypeService.createEventType(eventTypes);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@GetMapping
	public ResponseEntity<List<EventTypeDto>> getAllEventTypes() {
		List<EventTypeDto> eventTypeList = eventTypeService.getAllEventTypes();
		return ResponseEntity.status(HttpStatus.OK).body(eventTypeList);
	}

	@GetMapping("/{eventTypeId}")
	public ResponseEntity<EventTypeDto> getEventTypeById(@PathVariable String eventTypeId) {
		EventTypeDto eventTypeData = eventTypeService.getEventTypeById(eventTypeId);
		return ResponseEntity.status(HttpStatus.OK).body(eventTypeData);
	}

	@PutMapping("/{eventTypeId}")
	public ResponseEntity<Void> updateEventType(@PathVariable String eventTypeId,
			@Valid @RequestBody EventTypeEntity eventTypes) {
		eventTypeService.updateEventType(eventTypeId, eventTypes);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@DeleteMapping("/{eventTypeId}")
	public ResponseEntity<Void> deleteEventTypeById(@PathVariable String eventTypeId) {
		eventTypeService.deleteEventTypeById(eventTypeId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}
}
