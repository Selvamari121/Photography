package com.companyname.projectname.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.crm.dto.EventDto;
import com.companyname.projectname.crm.model.EventEntity;
import com.companyname.projectname.crm.service.EventService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/photographer/events")
public class EventController {

	@Autowired
	private EventService eventService;

	@PostMapping
	public ResponseEntity<Void> createEvent(@Valid @RequestBody EventEntity event) {
		eventService.createEvent(event);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@GetMapping("/project/{projectId}")
	public ResponseEntity<List<EventDto>> getAllEventsByProjectId(@PathVariable String projectId) {
		List<EventDto> eventsList = eventService.getAllEventsByProjectId(projectId);
		return ResponseEntity.status(HttpStatus.OK).body(eventsList);
	}

	@GetMapping("/{eventId}")
	public ResponseEntity<EventDto> getEventById(@PathVariable String eventId) {
		EventDto eventData = eventService.getEventById(eventId);
		return ResponseEntity.status(HttpStatus.OK).body(eventData);
	}

	@PutMapping("/{eventId}")
	public ResponseEntity<Void> updateEvent(@PathVariable String eventId, @Valid @RequestBody EventEntity event) {
		eventService.updateEvent(eventId, event);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@DeleteMapping("/{eventId}")
	public ResponseEntity<Void> deleteEvent(@PathVariable String eventId) {
		eventService.deleteEvent(eventId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}
}
