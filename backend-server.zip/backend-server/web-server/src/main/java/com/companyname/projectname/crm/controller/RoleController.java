package com.companyname.projectname.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.companyname.projectname.crm.dto.RoleDto;
import com.companyname.projectname.crm.model.RoleEntity;
import com.companyname.projectname.crm.service.RoleService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/photographer/roles")
public class RoleController {
	@Autowired
	private RoleService roleService;

	@PostMapping
	public ResponseEntity<Void> createRole(@Valid @RequestBody RoleEntity role) {
		roleService.createRole(role);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@GetMapping
	public ResponseEntity<List<RoleDto>> findAllRoles() {
		List<RoleDto> roleList = roleService.findAllRoles();
		return ResponseEntity.status(HttpStatus.OK).body(roleList);
	}

	@GetMapping("/{roleId}")
	public ResponseEntity<RoleDto> getRoleById(@PathVariable String roleId) {
		RoleDto roleData = roleService.getRoleById(roleId);
		return ResponseEntity.status(HttpStatus.OK).body(roleData);
	}

	@PutMapping("/{roleId}")
	public ResponseEntity<Void> updateRole(@PathVariable String roleId, @Valid @RequestBody RoleEntity updatedRole) {
		roleService.updateRole(roleId, updatedRole);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@DeleteMapping("/{roleId}")
	public ResponseEntity<Void> deleteRoleById(@PathVariable String roleId) {
		roleService.deleteRoleById(roleId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
	}
}
