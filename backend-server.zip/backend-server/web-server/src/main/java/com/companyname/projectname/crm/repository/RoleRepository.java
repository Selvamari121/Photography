package com.companyname.projectname.crm.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.companyname.projectname.crm.dto.RoleDto;
import com.companyname.projectname.crm.model.RoleEntity;

public interface RoleRepository extends JpaRepository<RoleEntity, Integer> {

	@Query("SELECT new com.companyname.projectname.crm.dto.RoleDto(r.roleId, r.name, r.description) "
			+ "FROM RoleEntity r ")
	List<RoleDto> findAllRole();

	@Query("SELECT new com.companyname.projectname.crm.dto.RoleDto(r.roleId, r.name, r.description) "
			+ "FROM RoleEntity r WHERE r.roleKey = :roleKey")
	Optional<RoleDto> findByRoleKey(@Param("roleKey") int roleKey);

}
