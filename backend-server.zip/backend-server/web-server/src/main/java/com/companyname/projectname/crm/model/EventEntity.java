package com.companyname.projectname.crm.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "event")
public class EventEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pk_evid")
	private int eventKey;

	@Column(name = "evid")
	private String eventId;

	// TODO: How to throw fk validation error to user
	@Column(name = "fk_prid")
	private int projectKey;

	@NotNull(message = "From date cannot be null")
	@Column(name = "from_time")
	private LocalDateTime fromDateTime;

	@NotNull(message = "To date cannot be null")
	// TODO: Pattern check?
	@Column(name = "to_time")
	private LocalDateTime toDateTime;

	@Column(name = "fk_evtid")
	private int eventTypeKey;

	@NotBlank(message = "Address link cannot be blank")
	@Size(max = 200, message = "Event address link cannot exceed 200 characters")
	@Column(name = "address_link")
	private String addressLink;

	@Size(max = 100, message = "Address line one cannot exceed 100 characters")
	@Column(name = "address_line1")
	private String addressLine1;

	@Size(max = 100, message = "Address line two cannot exceed 100 characters")
	@Column(name = "address_line2")
	private String addressLine2;

	@Size(max = 25, message = "City cannot exceed 25 characters")
	@Column(name = "city")
	private String city;

	@Size(max = 25, message = "State cannot exceed 25 characters")
	@Column(name = "state")
	private String state;

	@Size(max = 25, message = "Country cannot exceed 25 characters")
	@Column(name = "country")
	private String country;

	@Size(max = 6, message = "Pin code cannot exceed 6 characters")
	@Column(name = "pincode")
	private String pinCode;

	@Size(max = 255, message = "Event description cannot exceed 255 characters")
	@Column(name = "description")
	private String description;

	@Transient
	private String projectId;

	@Transient
	private String eventTypeId;
}
