package com.companyname.projectname.crm.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyname.projectname.crm.dto.ProjectTypeDto;
import com.companyname.projectname.crm.model.ProjectTypeEntity;
import com.companyname.projectname.crm.repository.ProjectTypeRepository;
import com.companyname.projectname.exception.ItemNotFoundException;
import com.companyname.projectname.util.KeyIdConversion;

@Service
public class ProjectTypeService {
	@Autowired
	private ProjectTypeRepository projectTypeRepository;

	@Autowired
	private KeyIdConversion conversion;

	public void createProjectType(ProjectTypeEntity projectTypes) {
		projectTypeRepository.save(projectTypes);
	}

	public List<ProjectTypeDto> getAllProjectTypes() {
		return projectTypeRepository.findAllProjectType();
	}

	public ProjectTypeDto getProjectTypeById(String projectTypeId) {
		int projectTypeKey = conversion.IdToKeyConversion(projectTypeId, 3);
		return projectTypeRepository.findByProjectTypeKey(projectTypeKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public void updateProjectType(String projectTypeId, ProjectTypeEntity projectTypes) {
		int projectTypeKey = conversion.IdToKeyConversion(projectTypeId, 3);
		ProjectTypeEntity existingEventType = projectTypeRepository.findById(projectTypeKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
		existingEventType.setName(projectTypes.getName());
		existingEventType.setDescription(projectTypes.getDescription());
		projectTypeRepository.save(existingEventType);
	}

	public void deleteProjectTypeById(String projectTypeId) {
		int projectTypeKey = conversion.IdToKeyConversion(projectTypeId, 3);
		if (!projectTypeRepository.existsById(projectTypeKey)) {
			throw new ItemNotFoundException("Item not found. Please try again.");
		}
		projectTypeRepository.deleteById(projectTypeKey);
	}
}
