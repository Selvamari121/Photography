package com.companyname.projectname.crm.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

	// TODO: Why this functionality?
	@GetMapping("/dashboard/home")
	public ResponseEntity<Void> getCustomerDashboard() {
		return ResponseEntity.status(HttpStatus.OK).build();
	}
}
