package com.companyname.projectname.crm.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyname.projectname.authentication.service.SecurityService;
import com.companyname.projectname.crm.dto.CrewDto;
import com.companyname.projectname.crm.model.CrewEntity;
import com.companyname.projectname.crm.repository.CrewRepository;
import com.companyname.projectname.exception.ItemNotFoundException;
import com.companyname.projectname.util.KeyIdConversion;

@Service
public class CrewService {
	@Autowired
	private CrewRepository crewRepository;

	@Autowired
	private KeyIdConversion conversion;

	@Autowired
	private SecurityService securityService;

	public void createCrew(CrewEntity crew) {
		int photographerKey = securityService.getPhotographerKey();
		int RoleKey = conversion.IdToKeyConversion(crew.getRoleId(), 2);
		CrewEntity crewEntity = new CrewEntity();
		crewEntity.setPhotographerKey(photographerKey);
		crewEntity.setFirstName(crew.getFirstName());
		crewEntity.setLastName(crew.getLastName());
		crewEntity.setRoleKey(RoleKey);
		crewRepository.save(crewEntity);
	}

	public List<CrewDto> getAllCrews(int photographerKey) {
		return crewRepository.findAllCrew(photographerKey);
	}

	public CrewDto getCrewById(String crewId) {
		int crewKey = conversion.IdToKeyConversion(crewId, 2);
		return crewRepository.findByCrewKey(crewKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
	}

	public void updateCrew(String crewId, CrewEntity updatedCrew) {
		int crewKey = conversion.IdToKeyConversion(crewId, 2);
		CrewEntity existingCrew = crewRepository.findById(crewKey)
				.orElseThrow(() -> new ItemNotFoundException("Item not found. Please try again."));
		int RoleKey = conversion.IdToKeyConversion(updatedCrew.getRoleId(), 2);
		existingCrew.setFirstName(updatedCrew.getFirstName());
		existingCrew.setLastName(updatedCrew.getLastName());
		existingCrew.setRoleKey(RoleKey);
		crewRepository.save(existingCrew);
	}

	public void deleteCrewById(String crewId) {
		int crewKey = conversion.IdToKeyConversion(crewId, 2);
		if (!crewRepository.existsById(crewKey)) {
			throw new ItemNotFoundException("Item not found. Please try again.");
		}
		crewRepository.deleteById(crewKey);
	}
}
