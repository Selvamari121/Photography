package com.companyname.projectname.util;

import org.springframework.stereotype.Component;

@Component
public class KeyIdConversion {

	public int IdToKeyConversion(String uniqueId, int prefixLength) {
		if (uniqueId == null || uniqueId.length() <= prefixLength) {
			throw new IllegalArgumentException("Invalid unique ID format: " + uniqueId);
		}

		String numericPart = uniqueId.substring(prefixLength);

		try {
			return Integer.parseInt(numericPart);
		} catch (NumberFormatException e) {
			throw new IllegalArgumentException("Numeric part of unique ID is not valid: " + numericPart, e);
		}
	}
}
