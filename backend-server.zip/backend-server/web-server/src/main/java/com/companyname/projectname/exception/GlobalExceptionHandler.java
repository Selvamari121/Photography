package com.companyname.projectname.exception;

import java.io.IOException;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.networknt.schema.JsonSchemaException;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.ServletException;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex) {
		StringBuilder errorMessages = new StringBuilder();

		ex.getBindingResult().getFieldErrors().forEach(error -> {
			if (errorMessages.length() > 0) {
				errorMessages.append(", ");
			}
			errorMessages.append(error.getDefaultMessage());
		});

		return new ResponseEntity<>(errorMessages.toString(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ItemNotFoundException.class)
	@ResponseBody
	public ResponseEntity<String> handleItemNotFoundException(ItemNotFoundException ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(UsernameNotFoundException.class)
	public ResponseEntity<String> handleUsernameNotFoundException(UsernameNotFoundException ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(DuplicateItemException.class)
	public ResponseEntity<String> handleDuplicateItemException(DuplicateItemException ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(ValidationException.class)
    public ResponseEntity<String> handleValidationException(ValidationException ex) { 
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    }

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleGenericException(Exception ex) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("An error occurred. Please try again later. " + ex);
	}

	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<String> handleDataIntegrityViolationException(DataIntegrityViolationException e) {
		return new ResponseEntity<>("Unable to process your request. Please check your data", HttpStatus.CONFLICT);
	}

	@ExceptionHandler(JsonProcessingException.class)
	public ResponseEntity<String> handleJsonProcessingException(JsonProcessingException ex) {
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please ensure the input is valid and try again.");
	}

	@ExceptionHandler(IOException.class)
	public ResponseEntity<String> handleIOException(IOException ex) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("An error occurred while processing your request. Please try again later.");
	}

	@ExceptionHandler(UnauthorizedException.class)
	public ResponseEntity<String> handleUnauthorizedException(UnauthorizedException ex) {
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
				.body("You are not authorized to perform this action. Please log in again.");
	}

	@ExceptionHandler(AuthenticationException.class)
	public ResponseEntity<String> handleAuthenticationException(AuthenticationException ex) {
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
				.body("Login failed. Please check your credentials and try again.");
	}

	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException ex) {
		return ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body("Invalid input provided. Please check your request and try again.");
	}

	@ExceptionHandler(ExpiredJwtException.class) // JWT token is expired
	public ResponseEntity<String> handleExpiredJwtException(ExpiredJwtException ex) {
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Please log in again.");
	}

	@ExceptionHandler(JwtException.class) // JWT token is invalid
	public ResponseEntity<String> handleJwtException(JwtException e) {
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Please log in again.");
	}

	@ExceptionHandler(ServletException.class)
	public ResponseEntity<String> handleServletException(ServletException ex) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Oops! Something went wrong while processing your request. Please try again later. ");
	}

	@ExceptionHandler(BadCredentialsException.class)
	public ResponseEntity<String> handleBadCredentialsException(BadCredentialsException ex) {
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password. Please try again.");
	}

	@ExceptionHandler(JsonSchemaException.class)
	public ResponseEntity<String> handleJsonSchemaException(JsonSchemaException ex, WebRequest request) {
		String errorMessage = "Invalid file" + ex.getMessage();
		return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
	}
}
