package com.companyname.projectname.crm.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class CrewDto {
	private String crewId;

	private String firstName;

	private String lastName;

	private String roleId;

	private String roleName;
}
