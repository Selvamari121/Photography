# backend-server
Entire backend functionalities are implemented here.
