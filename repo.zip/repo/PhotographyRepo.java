package com.payment.schedule.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.payment.schedule.model.Photography;

public interface PhotographyRepo extends JpaRepository<Photography, Long> {

   
}
