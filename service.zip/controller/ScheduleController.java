package com.payment.schedule.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.payment.schedule.model.Schedule;
import com.payment.schedule.service.ScheduleService;

@RestController
@RequestMapping("/schedule")
public class ScheduleController {
   @Autowired
   private ScheduleService service;  

   @PostMapping("/create")
   public ResponseEntity<String> addSchedule(@RequestBody Schedule schedule) {
      // System.out.println(schedule);
      service.saveSchedule(schedule);
      return ResponseEntity.status(HttpStatus.CREATED).build();
   }
   
   @GetMapping("/view/{schedule_id}")
   public ResponseEntity<Schedule> getScheduleById(@PathVariable Long schedule_id) {
      Schedule schedule = service.getScheduleById(schedule_id);
      return ResponseEntity.ok(schedule);
   }

   @GetMapping("/view/all")
   public ResponseEntity<List<Schedule>> getAllSchedules() {
      List<Schedule> schedules = service.findAllSchedules();
      return ResponseEntity.ok(schedules);
   }

   @DeleteMapping("/delete/{schedule_id}")
   public ResponseEntity<Void> deleteScheduleById(@PathVariable Long schedule_id) {
      service.deleteScheduleById(schedule_id);
      return ResponseEntity.noContent().build();  
   }
   @PutMapping("/edit/{schedule_id}")
   public ResponseEntity<Schedule> updatePaymentSchedule(@PathVariable Long schedule_id, @RequestBody Schedule schedule) {
      Schedule updatedSchedule = service.updatePaymentSchedule(schedule_id, schedule);
      return ResponseEntity.ok(updatedSchedule);
   }
}


// @PutMapping(value = "/schedule/edit/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
// public ResponseEntity<Schedule> updatePaymentSchedule( @PathVariable Long id, @RequestBody Schedule updatedSchedule) {
//    Schedule updatedPaymentSchedule = service.updatePaymentSchedule(id, updatedSchedule);
//    return ResponseEntity.ok(updatedPaymentSchedule);
// }




//    @PutMapping(value = "/your-endpoint", produces = "application/json")
// public ResponseEntity<YourResponseType> updateSchedule(@RequestBody YourRequestType request) {
//     // Your logic here
//     return ResponseEntity.ok(updatedSchedule);
// }                                                                                                                