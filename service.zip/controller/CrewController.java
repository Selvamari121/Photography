package com.crewandrole.management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
// import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.crewandrole.management_system.model.CrewEntity;
import com.crewandrole.management_system.service.CrewService;

@RestController
@RequestMapping("/crew")
public class CrewController {
   @Autowired
   private CrewService service; 

   @PostMapping("/addcrew")
   public ResponseEntity<CrewEntity> addCrew(@RequestBody CrewEntity crew) {
      CrewEntity savedCrew = service.saveCrew(crew); 
      // System.out.println("Saved Crew: " + savedCrew);
      return ResponseEntity.status(HttpStatus.CREATED).body(savedCrew);
   }
   @DeleteMapping("/deletecrew/{crid}")
   public ResponseEntity<Void> deleteCrewById(@PathVariable String crid) {
      service.deleteCrewById(crid);
      return ResponseEntity.noContent().build();  
   }
   @PutMapping("/editcrew/{crid}")
   public ResponseEntity<CrewEntity> updateCrew(@PathVariable String crid, @RequestBody CrewEntity updatedCrew) {
      CrewEntity updatedCrews = service.updateCrew(crid, updatedCrew);
      return ResponseEntity.ok(updatedCrews);
   }

}
   
   // @GetMapping("/view/{crid}")
   // public ResponseEntity<CrewEntity> getCrewById(@PathVariable String crid) {
   //    CrewEntity crews = service.getCrewById(crid);
   //    return ResponseEntity.ok(crews);
   // }
