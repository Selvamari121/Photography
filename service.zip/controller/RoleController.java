package com.crewandrole.management_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
// import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.crewandrole.management_system.model.RoleEntity;
import com.crewandrole.management_system.service.RoleService;

@RestController
@RequestMapping("/role")
public class RoleController {
   @Autowired
   private RoleService service; 

   @PostMapping("/addrole")
   public ResponseEntity<String> addRole(@RequestBody RoleEntity role) {
      //System.out.println(role);
      service.saveRole(role);
      return ResponseEntity.status(HttpStatus.CREATED).build();
   }
   @DeleteMapping("/deleterole/{roleid}")
   public ResponseEntity<Void> deleteRoleById(@PathVariable String roleid) {
      service.deleteRoleById(roleid);
      return ResponseEntity.noContent().build();  
   }

   @PutMapping("/editrole/{roleid}")
   public ResponseEntity<RoleEntity> updatedRole(@PathVariable String roleid, @RequestBody RoleEntity updatedRole) {
      RoleEntity updatedRoles = service.updatedRole(roleid, updatedRole);
      return ResponseEntity.ok(updatedRoles);
   }
}

   // @GetMapping("/view/{roleid}")
   // public ResponseEntity<RoleEntity> getRoleById(@PathVariable String roleid) {
   //    RoleEntity roles = service.getRoleById(roleid);
   //    return ResponseEntity.ok(roles);
   // }
