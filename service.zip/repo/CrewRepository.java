package com.crewandrole.management_system.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.crewandrole.management_system.model.CrewEntity;

public interface CrewRepository extends JpaRepository<CrewEntity, String> {

   
}
