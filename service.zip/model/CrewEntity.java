package com.crewandrole.management_system.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
@Table(name="crew_table")
public class CrewEntity {
   @Id
   @Column(length = 15)
   private String crid;

   @Column(length = 15) 
   private String phid;

   @Column(length = 15)
   private String roleid;

   @Column(length = 15) 
   private String name;

   @Column(length = 50)
   private String email;

   @Column(length = 10) 
   private String mobile;

   @Column(length = 10)
   private String pan;

   public CrewEntity(String crid, String phid, String roleid, String name, String email, String mobile, String pan) {
      this.crid = crid;
      this.phid = phid;
      this.roleid = roleid;
      this.name = name;
      this.email = email;
      this.mobile = mobile;
      this.pan = pan;
   }
   public CrewEntity(){

   } 

   @Override
   public String toString() {
      return "CrewEntity [crid=" + crid + ", phid=" + phid + ", roleid=" + roleid + ", name=" + name + ", email="
            + email + ", mobile=" + mobile + ", pan=" + pan + "]";
   }
}
