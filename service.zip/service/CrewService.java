package com.crewandrole.management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.crewandrole.management_system.model.CrewEntity;
import com.crewandrole.management_system.repo.CrewRepository;
import jakarta.persistence.EntityNotFoundException;

@Service
public class CrewService {
   @Autowired
   private CrewRepository repo;

   public CrewEntity saveCrew(CrewEntity crew) {
      return repo.save(crew);
   }

   public void deleteCrewById(String crid) {
      if (repo.existsById(crid)) {
         repo.deleteById(crid);
      } else {
         throw new EntityNotFoundException("Role not found with id " + crid);
      }
   }
  
   public CrewEntity updateCrew(String crid, CrewEntity updatedCrew) {
      return repo.findById(crid).map(existingCrew -> {
         existingCrew.setName(updatedCrew.getName());
         existingCrew.setEmail(updatedCrew.getEmail());
         existingCrew.setRoleid(updatedCrew.getRoleid());
         existingCrew.setMobile(updatedCrew.getMobile());
         existingCrew.setPan(updatedCrew.getPan());
         return repo.save(existingCrew);
      }).orElseThrow();
   }  
}

   // public CrewEntity getCrewById(String crid) {
   //    return repo.findById(crid).orElseThrow(() -> new EntityNotFoundException("Role not found with id " + crid));
   // }

   // public CrewEntity updateCrew(String crid, CrewEntity updatedCrew) {
   //    CrewEntity existingCrew = repo.findById(crid).orElseThrow(() -> new RuntimeException("Crew member not found with id " + crid));
   //    existingCrew.setRoleid(updatedCrew.getRoleid());
   //    existingCrew.setName(updatedCrew.getName());
   //    existingCrew.setEmail(updatedCrew.getEmail());
   //    existingCrew.setMobile(updatedCrew.getMobile());
   //    existingCrew.setPan(updatedCrew.getPan()); 
   //    return repo.save(existingCrew);
   // }