package com.crewandrole.management_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.crewandrole.management_system.model.RoleEntity;
import com.crewandrole.management_system.repo.RoleRepository;
import jakarta.persistence.EntityNotFoundException;

@Service
public class RoleService {
   @Autowired
   private RoleRepository repository;

   public void saveRole(RoleEntity role) {
      repository.save(role);
   }  
   public void deleteRoleById(String roleid) {
      if (repository.existsById(roleid)) {
         repository.deleteById(roleid);
      } else {
         throw new EntityNotFoundException("Role not found with id " + roleid);
      }
   }
   public RoleEntity updatedRole(String roleId, RoleEntity updatedRole) {
      return repository.findById(roleId).map(existingRole -> {
         existingRole.setName(updatedRole.getName());
         existingRole.setDescription(updatedRole.getDescription());
         return repository.save(existingRole);
      }).orElseThrow(() -> new EntityNotFoundException("Role not found"));
   }
}


   // public RoleEntity getRoleById(String roleid) {
   //    return repository.findById(roleid).orElseThrow(() -> new EntityNotFoundException("Role not found with id " + roleid));
   // }

   
   // public RoleEntity updatedRole(String roleid, RoleEntity updatedRole) {
   //    RoleEntity existingRole = repository.findById(roleid).orElseThrow(() -> new RuntimeException("Role not found with id " + roleid));
   //    existingRole.setName(updatedRole.getName());
   //    existingRole.setDescription(updatedRole.getDescription());
   //    return repository.save(existingRole);
   // }