package com.payment.schedule.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.payment.schedule.exception.ResourceNotFoundException;
import com.payment.schedule.model.Schedule;
import com.payment.schedule.repo.ScheduleRepo;
import jakarta.persistence.EntityNotFoundException;

@Service
public class ScheduleService {
   @Autowired
   private ScheduleRepo repository;

   public void saveSchedule(Schedule paymentschedule) {
      repository.save(paymentschedule);
      // Schedule payment = repository.save(paymentschedule);
      // System.out.println(payment);
   }
   public Schedule getScheduleById(Long id) {
      return repository.findById(id).orElseThrow(() -> new EntityNotFoundException("Photography event not found with id " + id));
   }

   public List<Schedule> findAllSchedules() {
      List<Schedule> events = repository.findAll();
      if (events.isEmpty()) {
         throw new EntityNotFoundException("No Photography events found");
      }
      return events;
   }

   public void deleteScheduleById(Long id) {
      if (repository.existsById(id)) {
         repository.deleteById(id);
      } else {
         throw new EntityNotFoundException("Photography event not found with id " + id);
      }
   }


   public Schedule updatePaymentSchedule(Long id, Schedule updatedSchedule) {
      Schedule existingSchedule = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("PaymentSchedule not found with id " + id));
      existingSchedule.setTotal_amount(updatedSchedule.getTotal_amount()); 
      existingSchedule.setSchedule_amount(updatedSchedule.getSchedule_amount());
      existingSchedule.setPayment_due_date(updatedSchedule.getPayment_due_date()); 
      existingSchedule.setIs_paid(updatedSchedule.getIs_paid());
      existingSchedule.setPayment_date(updatedSchedule.getPayment_date()); 
      existingSchedule.setProject_id(updatedSchedule.getProject_id()); 
      return repository.save(existingSchedule);
   }
   
}

