package com.payment.schedule.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.payment.schedule.exception.ResourceNotFoundException;
import com.payment.schedule.model.Schedule;
import com.payment.schedule.repo.ScheduleRepo;
import jakarta.persistence.EntityNotFoundException;

@Service
public class ScheduleService {
   @Autowired
   private ScheduleRepo repository;

   public void saveSchedule(Schedule schedule) {
      repository.save(schedule);
      // Schedule payment = repository.save(paymentschedule);
      // System.out.println(payment);
   }
   public Schedule getScheduleById(Long schedule_id) {
      return repository.findById(schedule_id).orElseThrow(() -> new EntityNotFoundException("Photography event not found with id " + schedule_id));
   }

   public List<Schedule> findAllSchedules() {
      List<Schedule> schedules = repository.findAll();
      if (schedules.isEmpty()) {
         throw new EntityNotFoundException("No Photography events found");
      }
      return schedules;
   }

   public void deleteScheduleById(Long schedule_id) {
      if (repository.existsById(schedule_id)) {
         repository.deleteById(schedule_id);
      } else {
         throw new EntityNotFoundException("Photography event not found with id " + schedule_id);
      }
   }


   public Schedule updatePaymentSchedule(Long schedule_id, Schedule updatedSchedule) {
      Schedule existingSchedule = repository.findById(schedule_id).orElseThrow(() -> new ResourceNotFoundException("PaymentSchedule not found with id " + schedule_id));
      existingSchedule.setTotal_amount(updatedSchedule.getTotal_amount()); 
      existingSchedule.setSchedule_amount(updatedSchedule.getSchedule_amount());
      existingSchedule.setPayment_due_date(updatedSchedule.getPayment_due_date()); 
      existingSchedule.setIs_paid(updatedSchedule.getIs_paid());
      existingSchedule.setPayment_date(updatedSchedule.getPayment_date()); 
      existingSchedule.setProject_id(updatedSchedule.getProject_id()); 
      return repository.save(existingSchedule);
   }
   
}

