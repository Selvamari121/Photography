package com.payment.schedule.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.payment.schedule.exception.ResourceNotFoundException;
import com.payment.schedule.model.Photography;
import com.payment.schedule.repo.PhotographyRepo;
import jakarta.persistence.EntityNotFoundException;

@Service
public class PhotographyService {
   @Autowired
   private PhotographyRepo repository;

   public void saveEvent(Photography paymentschedule) {
      Photography payment = repository.save(paymentschedule);
      System.out.println(payment);
   }
   public Photography getEventById(Long id) {
      return repository.findById(id).orElseThrow(() -> new EntityNotFoundException("Photography event not found with id " + id));
   }

   public List<Photography> findAllEvents() {
      List<Photography> events = repository.findAll();
      if (events.isEmpty()) {
         throw new EntityNotFoundException("No Photography events found");
      }
      return events;
   }

   public void deleteEventById(Long id) {
      if (repository.existsById(id)) {
         repository.deleteById(id);
      } else {
         throw new EntityNotFoundException("Photography event not found with id " + id);
      }
   }
   public Photography updatePaymentSchedule(Long id, Photography updatedSchedule) {
      Photography existingSchedule = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("PaymentSchedule not found with id " + id));
      existingSchedule.setTotal_amount(updatedSchedule.getTotal_amount()); 
      existingSchedule.setSchedule_amount(updatedSchedule.getSchedule_amount());
      existingSchedule.setPayment_due_date(updatedSchedule.getPayment_due_date()); 
      existingSchedule.setIs_paid(updatedSchedule.getIs_paid());
      existingSchedule.setProject_id(updatedSchedule.getProject_id()); 
      return repository.save(existingSchedule);
   }
   
}








   // public Photography getEvent(Long id) {
   //    return repository.findById(id).orElseThrow(() -> new EntityNotFoundException("Photography event not found with id " + id));
   // }

   // public void deleteEventById(Long id) {
   //    if (repository.existsById(id)) {
   //       repository.deleteById(id);
   //    } else {
   //       throw new EntityNotFoundException("Photography event not found with id " + id);
   //    }
   // }
   // public PaymentScheduleEntity updatePaymentSchedule(Long id, PaymentScheduleEntity updatedSchedule) {
   //    PaymentScheduleEntity existingSchedule = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("PaymentSchedule not found with id " + id));
   //    existingSchedule.setTotal_amount(updatedSchedule.getTotal_amount()); 
   //    existingSchedule.setSchedule_amount(updatedSchedule.getSchedule_amount());
   //    existingSchedule.setPayment_due_date(updatedSchedule.getPayment_due_date()); 
   //    existingSchedule.setIs_paid(updatedSchedule.getIs_paid());
   //    existingSchedule.setProduct_id(updatedSchedule.getProduct_id()); 
   //    return repository.save(existingSchedule);
   // }

   // public PaymentScheduleEntity updatePaymentSchedule(Long id, PaymentScheduleEntity updatedSchedule) {
   //    return repository.findById(id).map(existingSchedule -> {
   //       existingSchedule.setTotal_amount(updatedSchedule.getTotal_amount());
   //       existingSchedule.setSchedule_amount(updatedSchedule.getSchedule_amount());
   //       existingSchedule.setPayment_due_date(updatedSchedule.getPayment_due_date());
   //       existingSchedule.setIs_paid(updatedSchedule.getIs_paid());
   //       existingSchedule.setPayment_date(updatedSchedule.getPayment_date());
   //       return repository.save(existingSchedule);
   //    }).orElseThrow(() -> new EntityNotFoundException("PaymentSchedule not found with id " + id));
   // }