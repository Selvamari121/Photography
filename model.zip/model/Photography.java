package com.payment.schedule.model;

import java.math.BigDecimal;
import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="paymentschedule")
public class Photography {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;

   @Column(nullable = false)  
   private BigDecimal total_amount;

   @Column
   private BigDecimal schedule_amount;

   @Column(nullable = false)  
   private Date payment_due_date ;

   @Column(nullable = false) 
   private Boolean is_paid;

   @Column
   private Date payment_date ;
   @Column
   private Long project_id;
   
   public Long getId() {
      return id;
   }
   public void setId(Long id) {
      this.id = id;
   }
   public BigDecimal getTotal_amount() {
      return total_amount;
   }
   public void setTotal_amount(BigDecimal total_amount) {
      this.total_amount = total_amount;
   }
   public BigDecimal getSchedule_amount() {
      return schedule_amount;
   }
   public void setSchedule_amount(BigDecimal schedule_amount) {
      this.schedule_amount = schedule_amount;
   }
   public Date getPayment_due_date() {
      return payment_due_date;
   }
   public void setPayment_due_date(Date payment_due_date) {
      this.payment_due_date = payment_due_date;
   }
   public Boolean getIs_paid() {
      return is_paid;
   }
   public void setIs_paid(Boolean is_paid) {
      this.is_paid = is_paid;
   }
   public Date getPayment_date() {
      return payment_date;
   }
   public void setPayment_date(Date payment_date) {
      this.payment_date = payment_date;
   }
   public Long getProject_id() {
      return project_id;
   }
   public void setProject_id(Long project_id) {
      this.project_id = project_id;
   }

   public Photography(){
      
   }
   public Photography(Long id, BigDecimal total_amount, BigDecimal schedule_amount, Date payment_due_date,
         Boolean is_paid, Date payment_date, Long project_id) {
      this.id = id;
      this.total_amount = total_amount;
      this.schedule_amount = schedule_amount;
      this.payment_due_date = payment_due_date;
      this.is_paid = is_paid;
      this.payment_date = payment_date;
      this.project_id = project_id;
   }
   @Override
   public String toString() {
      return "Photography [id=" + id + ", total_amount=" + total_amount + ", schedule_amount=" + schedule_amount
            + ", payment_due_date=" + payment_due_date + ", is_paid=" + is_paid + ", payment_date=" + payment_date
            + ", project_id=" + project_id + "]";
   }


}