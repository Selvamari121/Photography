package com.payment.schedule.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.payment.schedule.model.Photography;
import com.payment.schedule.service.PhotographyService;

@RestController
@RequestMapping("/schedule")
public class PhotographyController {
   @Autowired
   private PhotographyService service;  

   @PostMapping("/create")
   public ResponseEntity<String> addEvent(@RequestBody Photography paymentschedule) {
      System.out.println(paymentschedule);
      service.saveEvent(paymentschedule);
      return ResponseEntity.status(HttpStatus.CREATED).build();
   }
   
   @GetMapping("/view/{id}")
   public ResponseEntity<Photography> getEventById(@PathVariable Long id) {
      Photography event = service.getEventById(id);
      return ResponseEntity.ok(event);
   }

   @GetMapping("/view/all")
    public ResponseEntity<List<Photography>> getAllEvents() {
        List<Photography> events = service.findAllEvents();
        return ResponseEntity.ok(events);
    }

   @DeleteMapping("/delete/{id}")
   public ResponseEntity<Void> deleteEventById(@PathVariable Long id) {
      service.deleteEventById(id);
      return ResponseEntity.noContent().build();  
   }
   
   @PutMapping("/edit/{id}")
   public ResponseEntity<Photography> updatePaymentSchedule( @PathVariable Long id, @RequestBody Photography updatedSchedule) {
      Photography updatedPaymentSchedule = service.updatePaymentSchedule(id, updatedSchedule);
      return ResponseEntity.ok(updatedPaymentSchedule);
   }

}






   // @GetMapping("/view")
   // public ResponseEntity<Photography> getEventById(@PathVariable Long id) {
   //    Photography event = service.getEventById(id);
   //    return ResponseEntity.ok(event);
   // }







//   @GetMapping("/view")
//    public ResponseEntity<Photography> getEventById(@PathVariable Long id) {
//       Photography event = service.getEventById(id);
//       return ResponseEntity.ok(event);
//    }
   
//    @GetMapping("/view/{id}")
//    public ResponseEntity<PaymentScheduleEntity> getEventById(@PathVariable Long id) {
//       PaymentScheduleEntity event = service.getEventById(id);
//       return ResponseEntity.ok(event);
//    }
//    @DeleteMapping("/delete/{id}")
//    public ResponseEntity<Void> deleteEventById(@PathVariable Long id) {
//       service.deleteEventById(id);
//       return ResponseEntity.noContent().build();  
//    }
   
//    @PutMapping("/edit/{id}")
//    public ResponseEntity<PaymentScheduleEntity> updatePaymentSchedule( @PathVariable Long id, @RequestBody PaymentScheduleEntity updatedSchedule) {
//       PaymentScheduleEntity updatedPaymentSchedule = service.updatePaymentSchedule(id, updatedSchedule);
//       return ResponseEntity.ok(updatedPaymentSchedule);
//    }
