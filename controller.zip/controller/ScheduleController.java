package com.payment.schedule.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.payment.schedule.model.Schedule;
import com.payment.schedule.service.ScheduleService;

@RestController
@RequestMapping("/schedule")
public class ScheduleController {
   @Autowired
   private ScheduleService service;  

   @PostMapping("/create")
   public ResponseEntity<String> addSchedule(@RequestBody Schedule paymentschedule) {
      System.out.println(paymentschedule);
      service.saveSchedule(paymentschedule);
      return ResponseEntity.status(HttpStatus.CREATED).build();
   }
   
   @GetMapping("/view/{id}")
   public ResponseEntity<Schedule> getScheduleById(@PathVariable Long id) {
      Schedule event = service.getScheduleById(id);
      return ResponseEntity.ok(event);
   }

   @GetMapping("/view/all")
   public ResponseEntity<List<Schedule>> getAllSchedules() {
      List<Schedule> events = service.findAllSchedules();
      return ResponseEntity.ok(events);
   }

   @DeleteMapping("/delete/{id}")
   public ResponseEntity<Void> deleteScheduleById(@PathVariable Long id) {
      service.deleteScheduleById(id);
      return ResponseEntity.noContent().build();  
   }
   @PutMapping("/edit/{id}")
   public ResponseEntity<Schedule> updatePaymentSchedule(@PathVariable Long id, @RequestBody Schedule schedule) {
       Schedule updatedSchedule = service.updatePaymentSchedule(id, schedule);
       return ResponseEntity.ok(updatedSchedule);
   }

}


// @PutMapping(value = "/schedule/edit/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
// public ResponseEntity<Schedule> updatePaymentSchedule( @PathVariable Long id, @RequestBody Schedule updatedSchedule) {
//    Schedule updatedPaymentSchedule = service.updatePaymentSchedule(id, updatedSchedule);
//    return ResponseEntity.ok(updatedPaymentSchedule);
// }




//    @PutMapping(value = "/your-endpoint", produces = "application/json")
// public ResponseEntity<YourResponseType> updateSchedule(@RequestBody YourRequestType request) {
//     // Your logic here
//     return ResponseEntity.ok(updatedSchedule);
// }                                                                                                                