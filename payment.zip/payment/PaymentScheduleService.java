// package com.yourpackage.service;

// import com.yourpackage.model.PaymentSchedule;
// import com.yourpackage.repository.PaymentScheduleRepository;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;

// import java.util.List;
// import java.util.Optional;

// @Service
// public class PaymentScheduleService {
//     @Autowired
//     private PaymentScheduleRepository repository;

//     public PaymentSchedule create(PaymentSchedule schedule) {
//         // Add validation logic
//         return repository.save(schedule);
//     }

//     public void delete(Long scheduleId) {
//         repository.deleteById(scheduleId);
//     }

//     public Optional<PaymentSchedule> findById(Long scheduleId) {
//         return repository.findById(scheduleId);
//     }

//     public List<PaymentSchedule> findAllByProjectId(Long projectId) {
//         return repository.findByProjectId(projectId);
//     }

//     public PaymentSchedule update(PaymentSchedule schedule) {
//         return repository.save(schedule);
//     }
// }




package com.yourpackage.service;

import com.yourpackage.model.PaymentSchedule;
import com.yourpackage.repository.PaymentScheduleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class PaymentScheduleService {

    @Autowired
    private PaymentScheduleRepository repository;

    public PaymentSchedule create(PaymentSchedule schedule) {
        validateSchedule(schedule);
        return repository.save(schedule);
    }

    public void delete(Long scheduleId) {
        try {
            repository.deleteById(scheduleId);
        } catch (EmptyResultDataAccessException e) {
            // Handle case where the schedule ID does not exist
            throw new IllegalArgumentException("Schedule with ID " + scheduleId + " does not exist.");
        }
    }

    public Optional<PaymentSchedule> findById(Long scheduleId) {
        return repository.findById(scheduleId);
    }

    public List<PaymentSchedule> findAllByProjectId(Long projectId) {
        return repository.findByProjectId(projectId);
    }

    public PaymentSchedule update(PaymentSchedule schedule) {
        // Ensure that the schedule exists before updating
        if (!repository.existsById(schedule.getScheduleId())) {
            throw new IllegalArgumentException("Schedule with ID " + schedule.getScheduleId() + " does not exist.");
        }
        validateSchedule(schedule);
        return repository.save(schedule);
    }

    private void validateSchedule(PaymentSchedule schedule) {
        // Validate that ProjectId exists (Assuming you have a ProjectService to check this)
        // Example: if (!projectService.existsById(schedule.getProjectId())) {
        //     throw new IllegalArgumentException("Project with ID " + schedule.getProjectId() + " does not exist.");
        // }

        if (schedule.getTotalAmount() == null || schedule.getTotalAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("TotalAmount must be a positive number.");
        }
        if (schedule.getScheduleAmount() != null && schedule.getScheduleAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("ScheduleAmount must be a positive number.");
        }
        if (schedule.getPaymentDueDate() != null && schedule.getPaymentDueDate().isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("PaymentDueDate cannot be in the past.");
        }
    }
}
