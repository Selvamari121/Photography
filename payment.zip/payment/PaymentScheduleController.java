package com.yourpackage.controller;

import com.yourpackage.model.PaymentSchedule;
import com.yourpackage.service.PaymentScheduleService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/schedule")
public class PaymentScheduleController {
    @Autowired
    private PaymentScheduleService service;

    @PostMapping("/create")
    public ResponseEntity<PaymentSchedule> create(@RequestBody PaymentSchedule schedule) {
        return ResponseEntity.ok(service.create(schedule));
    }

    @DeleteMapping("/delete/{scheduleId}")
    public ResponseEntity<Void> delete(@PathVariable Long scheduleId) {
        service.delete(scheduleId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/view/{scheduleId}")
    public ResponseEntity<PaymentSchedule> view(@PathVariable Long scheduleId) {
        Optional<PaymentSchedule> schedule = service.findById(scheduleId);
        return schedule.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/viewAll/{projectId}")
    public ResponseEntity<List<PaymentSchedule>> viewAll(@PathVariable Long projectId) {
        return ResponseEntity.ok(service.findAllByProjectId(projectId));
    }

    @PutMapping("/edit")
    public ResponseEntity<PaymentSchedule> edit(@RequestBody PaymentSchedule schedule) {
        return ResponseEntity.ok(service.update(schedule));
    }
}
