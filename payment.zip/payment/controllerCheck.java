package com.yourpackage.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yourpackage.model.PaymentSchedule;
import com.yourpackage.service.PaymentScheduleService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class PaymentScheduleControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private PaymentScheduleService service;

    private PaymentSchedule testSchedule;

    @BeforeEach
    public void setUp() {
        // Initialize test data
        testSchedule = new PaymentSchedule(
            1L, // Assuming projectId is 1L for the test
            new BigDecimal("1000.00"),
            new BigDecimal("250.00"),
            LocalDate.now().plusDays(10),
            false,
            null
        );
    }

    @Test
    public void testCreateSchedule() throws Exception {
        mockMvc.perform(post("/schedule/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testSchedule)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.scheduleId").isNotEmpty())
            .andExpect(jsonPath("$.projectId").value(1))
            .andExpect(jsonPath("$.totalAmount").value("1000.00"))
            .andExpect(jsonPath("$.scheduleAmount").value("250.00"))
            .andExpect(jsonPath("$.paymentDueDate").value(testSchedule.getPaymentDueDate().toString()))
            .andExpect(jsonPath("$.isPaid").value(false))
            .andExpect(jsonPath("$.paymentDate").isEmpty());
    }

    @Test
    public void testDeleteSchedule() throws Exception {
        // Create a schedule first
        PaymentSchedule savedSchedule = service.create(testSchedule);

        mockMvc.perform(delete("/schedule/delete/{scheduleId}", savedSchedule.getScheduleId()))
            .andExpect(status().isNoContent());
    }

    @Test
    public void testViewSchedule() throws Exception {
        // Create a schedule first
        PaymentSchedule savedSchedule = service.create(testSchedule);

        mockMvc.perform(get("/schedule/view/{scheduleId}", savedSchedule.getScheduleId()))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.scheduleId").value(savedSchedule.getScheduleId()))
            .andExpect(jsonPath("$.projectId").value(savedSchedule.getProjectId()))
            .andExpect(jsonPath("$.totalAmount").value("1000.00"))
            .andExpect(jsonPath("$.scheduleAmount").value("250.00"))
            .andExpect(jsonPath("$.paymentDueDate").value(testSchedule.getPaymentDueDate().toString()))
            .andExpect(jsonPath("$.isPaid").value(false))
            .andExpect(jsonPath("$.paymentDate").isEmpty());
    }

    @Test
    public void testViewAllSchedules() throws Exception {
        // Create a schedule first
        service.create(testSchedule);

        mockMvc.perform(get("/schedule/viewAll/{projectId}", testSchedule.getProjectId()))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].projectId").value(testSchedule.getProjectId()))
            .andExpect(jsonPath("$[0].totalAmount").value("1000.00"))
            .andExpect(jsonPath("$[0].scheduleAmount").value("250.00"))
            .andExpect(jsonPath("$[0].paymentDueDate").value(testSchedule.getPaymentDueDate().toString()))
            .andExpect(jsonPath("$[0].isPaid").value(false))
            .andExpect(jsonPath("$[0].paymentDate").isEmpty());
    }

    @Test
    public void testEditSchedule() throws Exception {
        // Create a schedule first
        PaymentSchedule savedSchedule = service.create(testSchedule);

        savedSchedule.setScheduleAmount(new BigDecimal("300.00"));
        savedSchedule.setPaymentDueDate(LocalDate.now().plusDays(20));

        mockMvc.perform(put("/schedule/edit")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(savedSchedule)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.scheduleAmount").value("300.00"))
            .andExpect(jsonPath("$.paymentDueDate").value(savedSchedule.getPaymentDueDate().toString()));
    }
}
