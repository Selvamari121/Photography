// package com.yourpackage.model;

// import javax.persistence.*;
// import java.math.BigDecimal;
// import java.time.LocalDate;

// @Entity
// @Table(name = "payment_schedule")
// public class PaymentSchedule {
//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private UUID scheduleId;

//     @Column(name = "project_id", nullable = false)
//     private UUID projectId;

//     @Column(name = "total_amount", nullable = false)
//     private BigDecimal totalAmount;

//     @Column(name = "schedule_amount")
//     private BigDecimal scheduleAmount;

//     @Column(name = "payment_due_date")
//     private LocalDate paymentDueDate;

//     @Column(name = "is_paid")
//     private Boolean isPaid;

//     @Column(name = "payment_date")
//     private LocalDate paymentDate;

//     // Getters and setters
// }



package com.yourpackage.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "payment_schedule")
public class PaymentSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "schedule_id")
    private Long scheduleId;

    @Column(name = "project_id", nullable = false)
    private Long projectId;

    @Column(name = "total_amount", nullable = false)
    private BigDecimal totalAmount;

    @Column(name = "schedule_amount")
    private BigDecimal scheduleAmount;

    @Column(name = "payment_due_date")
    private LocalDate paymentDueDate;

    @Column(name = "is_paid")
    private Boolean isPaid;

    @Column(name = "payment_date")
    private LocalDate paymentDate;

    // Constructors
    public PaymentSchedule() {
        // Default constructor
    }

    public PaymentSchedule(Long projectId, BigDecimal totalAmount, BigDecimal scheduleAmount, LocalDate paymentDueDate, Boolean isPaid, LocalDate paymentDate) {
        this.projectId = projectId;
        this.totalAmount = totalAmount;
        this.scheduleAmount = scheduleAmount;
        this.paymentDueDate = paymentDueDate;
        this.isPaid = isPaid;
        this.paymentDate = paymentDate;
    }

    // Getters and Setters
    public Long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {
        this.scheduleId = scheduleId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getScheduleAmount() {
        return scheduleAmount;
    }

    public void setScheduleAmount(BigDecimal scheduleAmount) {
        this.scheduleAmount = scheduleAmount;
    }

    public LocalDate getPaymentDueDate() {
        return paymentDueDate;
    }

    public void setPaymentDueDate(LocalDate paymentDueDate) {
        this.paymentDueDate = paymentDueDate;
    }

    public Boolean getIsPaid() {
        return isPaid;
    }

    public void setIsPaid(Boolean isPaid) {
        this.isPaid = isPaid;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }

    @Override
    public String toString() {
        return "PaymentSchedule{" +
                "scheduleId=" + scheduleId +
                ", projectId=" + projectId +
                ", totalAmount=" + totalAmount +
                ", scheduleAmount=" + scheduleAmount +
                ", paymentDueDate=" + paymentDueDate +
                ", isPaid=" + isPaid +
                ", paymentDate=" + paymentDate +
                '}';
    }
}
