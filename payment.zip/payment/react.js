// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// function PaymentScheduleList() {
//   const [schedules, setSchedules] = useState([]);

//   useEffect(() => {
//     axios.get('/schedule/viewAll/1') // Replace with actual projectId
//       .then(response => setSchedules(response.data))
//       .catch(error => console.error('Error fetching schedules:', error));
//   }, []);

//   return (
//     <div>
//       <h1>Payment Schedules</h1>
//       <ul>
//         {schedules.map(schedule => (
//           <li key={schedule.scheduleId}>
//             {schedule.scheduleAmount} due on {schedule.paymentDueDate}
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// }

// export default PaymentScheduleList;

import React, { useState, useEffect } from 'react';
import axios from 'axios';

function PaymentScheduleList({ projectId }) {
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSchedules = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`/schedule/viewAll/${projectId}`);
        setSchedules(response.data);
      } catch (err) {
        setError(err);
        console.error('Error fetching schedules:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchSchedules();
  }, [projectId]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error loading schedules: {error.message}</p>;

  return (
    <div>
      <h1>Payment Schedules</h1>
      {schedules.length > 0 ? (
        <ul>
          {schedules.map(schedule => (
            <li key={schedule.scheduleId}>
              {schedule.scheduleAmount} due on {new Date(schedule.paymentDueDate).toLocaleDateString()}
            </li>
          ))}
        </ul>
      ) : (
        <p>No payment schedules found.</p>
      )}
    </div>
  );
}

export default PaymentScheduleList;





// In a parent component or App
import PaymentScheduleList from './PaymentScheduleList';

function App() {
  const projectId = 1; // Replace with actual project ID

  return (
    <div>
      <PaymentScheduleList projectId={projectId} />
    </div>
  );
}

export default App;
