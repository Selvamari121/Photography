package com.yourpackage.repository;

import com.yourpackage.model.PaymentSchedule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentScheduleRepository extends JpaRepository<PaymentSchedule, Long> {
    List<PaymentSchedule> findByProjectId(Long projectId);
}


// Find schedules with specific amount greater than a given value
List<PaymentSchedule> findByScheduleAmountGreaterThan(BigDecimal amount);

// Find schedules that are paid or unpaid
List<PaymentSchedule> findByIsPaid(Boolean isPaid);

// Find schedules with a due date before a specific date
List<PaymentSchedule> findByPaymentDueDateBefore(LocalDate date);

// Find schedules by projectId with pagination and sorting
Page<PaymentSchedule> findByProjectId(Long projectId, Pageable pageable);
