package com.payment.schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PhotographyService {
   @Autowired
   private PhotographyRepo repository;

   public void saveEvent(Photography event) {
      Photography dayEvent = repository.save(event);
      System.out.println(dayEvent);
  }

}
