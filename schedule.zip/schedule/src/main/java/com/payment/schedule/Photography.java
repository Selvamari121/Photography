package com.payment.schedule;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

// import java.math.BigDecimal;
// import java.sql.Date;

// import jakarta.persistence.Column;
// import jakarta.persistence.Entity;
// import jakarta.persistence.GeneratedValue;
// import jakarta.persistence.GenerationType;
// import jakarta.persistence.Id;
// import jakarta.persistence.Table;

@Entity
@Table(name = "events")
public class Photography {
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;

   @Column(nullable = false)  
   private String name;

   @Column(nullable = false)  
   private String date;

   @Column
    private String description;

   @Column
   private String location;

    // Default constructor is required by JPA
   public Photography() {
   }

   public Photography(String name, String date, String description, String location) {
      this.name = name;
      this.date = date;
      this.description = description;
      this.location = location;
   }

  // Getters and setters
   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   } 

   public String getDate() {
      return date;
   }

   public void setDate(String date) {
      this.date = date;
   }

   public String getDescription() {
      return description;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   public String getLocation() {
      return location;
   }

   public void setLocation(String location) {
      this.location = location;
   }
  
   @Override
   public String toString() {
      return "Event{" +
              "id=" + id +
              ", name='" + name + '\'' +
              ", date='" + date + '\'' +
              ", description='" + description + '\'' +
              ", location='" + location + '\'' +
              '}';
   }
  

   // @Id
   // @GeneratedValue(strategy = GenerationType.IDENTITY)
   // @Column(name="id")
   // private Long ScheduleId;

   // @Column(name="total")
   // private BigDecimal TotalAmount;

   // @Column(name="schedule")
   // private BigDecimal ScheduleAmount;

   // @Column(name="payment")
   // private Date PaymentDueDate;

   // public Long getScheduleId() {
   //    return ScheduleId;
   // }

   // public void setScheduleId(Long scheduleId) {
   //    ScheduleId = scheduleId;
   // }

   // public BigDecimal getTotalAmount() {
   //    return TotalAmount;
   // }

   // public void setTotalAmount(BigDecimal totalAmount) {
   //    TotalAmount = totalAmount;
   // }

   // public BigDecimal getScheduleAmount() {
   //    return ScheduleAmount;
   // }

   // public void setScheduleAmount(BigDecimal scheduleAmount) {
   //    ScheduleAmount = scheduleAmount;
   // }

   // public Date getPaymentDueDate() {
   //    return PaymentDueDate;
   // }

   // public void setPaymentDueDate(Date paymentDueDate) {
   //    PaymentDueDate = paymentDueDate;
   // }

   // @Override
   // public String toString() {
   //    return "Photography [ScheduleId=" + ScheduleId + ", TotalAmount=" + TotalAmount + ", ScheduleAmount="
   //          + ScheduleAmount + ", PaymentDueDate=" + PaymentDueDate + "]";
   // }
}
