package com.payment.schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/schedule")
public class PhotographyController {
   @Autowired
   private PhotographyService service;   
   
   @PostMapping("/events")
   public ResponseEntity<String> addEvent(@RequestBody Photography event) {
      System.out.println(event);
   service.saveEvent(event);
   return ResponseEntity.status(HttpStatus.CREATED).build();
}
}