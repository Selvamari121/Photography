package com.payment.schedule;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PhotographyRepo extends JpaRepository<Photography, Long> {

   
}
