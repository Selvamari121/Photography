package com.crewandrole.management_system;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.crewandrole.management_system.model.RoleEntity;
import com.crewandrole.management_system.repo.RoleRepository;
import com.crewandrole.management_system.service.RoleService;

import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class RoleServiceTest {

   @Mock
   private RoleRepository repository;

   @InjectMocks
   private RoleService service;

   @Test
   void saveRole() {
      RoleEntity role = new RoleEntity("ADMIN", "Admin", "Administrator role");
      service.saveRole(role);
      verify(repository, times(1)).save(role);
   }

   @Test
   void deleteRoleById() {
      String roleId = "ADMIN";
      when(repository.existsById(roleId)).thenReturn(true);
      service.deleteRoleById(roleId);
      verify(repository, times(1)).deleteById(roleId);
   }

   @Test
   void updatedRole() {
      String roleId = "ADMIN";
      RoleEntity existingRole = new RoleEntity(roleId, "Admin", "Administrator role");
      RoleEntity updatedRole = new RoleEntity(roleId, "Admin Updated", "Updated role description");
      when(repository.findById(roleId)).thenReturn(Optional.of(existingRole));
      when(repository.save(existingRole)).thenReturn(existingRole);
      RoleEntity result = service.updatedRole(roleId, updatedRole);
      assertEquals("Admin Updated", result.getName());
      assertEquals("Updated role description", result.getDescription());
      verify(repository, times(1)).save(existingRole);
   }
}



   //  @Test
   //  void deleteRoleById_shouldThrowExceptionWhenNotExists() {
   //      String roleId = "ADMIN";
   //      when(repository.existsById(roleId)).thenReturn(false);

   //      assertThrows(EntityNotFoundException.class, () -> service.deleteRoleById(roleId));
   //  }

//  @Test
   //  void updatedRole_shouldThrowExceptionWhenRoleNotFound() {
   //      String roleId = "ADMIN";
   //      RoleEntity updatedRole = new RoleEntity(roleId, "Admin Updated", "Updated role description");

   //      when(repository.findById(roleId)).thenReturn(Optional.empty());

   //      assertThrows(RuntimeException.class, () -> service.updatedRole(roleId, updatedRole));
   //  }