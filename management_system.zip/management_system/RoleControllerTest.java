package com.crewandrole.management_system;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.crewandrole.management_system.controller.RoleController;
import com.crewandrole.management_system.model.RoleEntity;
import com.crewandrole.management_system.service.RoleService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(RoleController.class)
public class RoleControllerTest {

   @Autowired
   private MockMvc mockMvc;

   @MockBean
   private RoleService roleService;

   @Autowired
   private ObjectMapper objectMapper;
   private RoleEntity role;

   @BeforeEach
   public void setup() {
      role = new RoleEntity();
      role.setRoleid("ADMIN");
      role.setName("Admin");
      role.setDescription("Administrator role");
   }

   @Test
   public void testAddRole() throws Exception {
      mockMvc.perform(post("/role/addrole")
             .contentType(MediaType.APPLICATION_JSON)
             .content(objectMapper.writeValueAsString(role)))
             .andExpect(status().isCreated());
      verify(roleService, times(1)).saveRole(any(RoleEntity.class));
   }
   @Test
   public void testDeleteRoleById() throws Exception {
      mockMvc.perform(delete("/role/deleterole/ADMIN"))
             .andExpect(status().isNoContent());

      verify(roleService, times(1)).deleteRoleById("ADMIN");
   }
   @Test
   void updateRole() throws Exception {
      String roleId = "ADMIN";
       // RoleEntity existingRole = new RoleEntity(roleId, "Admin", "Administrator role");
      RoleEntity updatedRole = new RoleEntity(roleId, "Admin Updated", "Updated role description");
      when(roleService.updatedRole(eq(roleId), any(RoleEntity.class))).thenReturn(updatedRole);
      mockMvc.perform(put("/role/editrole/{roleid}", roleId)
             .contentType(MediaType.APPLICATION_JSON)
             .content(objectMapper.writeValueAsString(updatedRole)))
             .andExpect(status().isOk())
             .andExpect(jsonPath("$.name").value("Admin Updated"))
             .andExpect(jsonPath("$.description").value("Updated role description"));
      verify(roleService, times(1)).updatedRole(eq(roleId), any(RoleEntity.class));
   }

}