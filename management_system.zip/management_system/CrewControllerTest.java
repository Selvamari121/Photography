package com.crewandrole.management_system;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.http.MediaType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import com.crewandrole.management_system.controller.CrewController;
import com.crewandrole.management_system.model.CrewEntity;
import com.crewandrole.management_system.service.CrewService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(CrewController.class)
class CrewControllerTest {

   @Autowired
   private MockMvc mockMvc;

   @MockBean
   private CrewService service;

   @Autowired
   private ObjectMapper objectMapper;

   @Test
   void addCrew() throws Exception {
      CrewEntity crew = new CrewEntity("CR01", "PH01", "ADMIN", "John Doe", "john@example.com", "1234567890", "ABCDE1234F");
        
      when(service.saveCrew(any(CrewEntity.class))).thenReturn(crew);

      mockMvc.perform(post("/crew/addcrew")
             .contentType(MediaType.APPLICATION_JSON)
             .content(objectMapper.writeValueAsString(crew)))
             .andExpect(status().isCreated())
             .andExpect(jsonPath("$.crid").value(crew.getCrid()))
             .andExpect(jsonPath("$.phid").value(crew.getPhid()))
             .andExpect(jsonPath("$.roleid").value(crew.getRoleid()))
             .andExpect(jsonPath("$.name").value(crew.getName()))
             .andExpect(jsonPath("$.email").value(crew.getEmail()))
             .andExpect(jsonPath("$.mobile").value(crew.getMobile()))
             .andExpect(jsonPath("$.pan").value(crew.getPan()));
   }
   @Test
   void deleteCrewById() throws Exception {
      String crid = "CR01";
      doNothing().when(service).deleteCrewById(crid);

      mockMvc.perform(delete("/crew/deletecrew/{crid}", crid))
             .andExpect(status().isNoContent());

      verify(service, times(1)).deleteCrewById(crid);
   }
   @Test
   void updateCrew() throws Exception {
      String crid = "CR01";
      CrewEntity updatedCrew = new CrewEntity(crid, "PH01", "ADMIN", "John Smith", "johnsmith@example.com", "0987654321", "ABCDE1234F");
      when(service.updateCrew(eq(crid), any(CrewEntity.class))).thenReturn(updatedCrew);
      mockMvc.perform(put("/crew/editcrew/{crid}", crid)
             .contentType(MediaType.APPLICATION_JSON)
             .content(objectMapper.writeValueAsString(updatedCrew)))
             .andExpect(status().isOk())
             .andExpect(jsonPath("$.phid").value("PH01"))
             .andExpect(jsonPath("$.roleid").value("ADMIN"))
             .andExpect(jsonPath("$.name").value("John Smith"))
             .andExpect(jsonPath("$.email").value("johnsmith@example.com"))
             .andExpect(jsonPath("$.mobile").value("0987654321"))
             .andExpect(jsonPath("$.pan").value("ABCDE1234F"));
      verify(service, times(1)).updateCrew(eq(crid), any(CrewEntity.class));
   }
}
