package com.crewandrole.management_system;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.crewandrole.management_system.model.CrewEntity;
import com.crewandrole.management_system.repo.CrewRepository;
import com.crewandrole.management_system.service.CrewService;

@ExtendWith(MockitoExtension.class)
class CrewServiceTest {

   @Mock
   private CrewRepository repo;

   @InjectMocks
   private CrewService service;

   @Test
   void saveCrew() {
      CrewEntity crew = new CrewEntity("CR01", "PH01", "ADMIN", "John Doe", "john@example.com", "1234567890", "ABCDE1234F");
      service.saveCrew(crew);
      verify(repo, times(1)).save(crew);
   }

   @Test
   void deleteCrewById() {
      String crid = "CR01";
      when(repo.existsById(crid)).thenReturn(true);
      service.deleteCrewById(crid);
      verify(repo, times(1)).deleteById(crid);
   }

   @Test
   void updateCrew() {
      String crid = "CR01";
      CrewEntity existingCrew = new CrewEntity(crid, "PH01", "ADMIN", "John Doe", "john@example.com", "1234567890", "ABCDE1234F");
      CrewEntity updatedCrew = new CrewEntity(crid, "PH01", "ADMIN", "John Smith", "johnsmith@example.com", "0987654321", "ABCDE1234F");
      when(repo.findById(crid)).thenReturn(Optional.of(existingCrew));
      when(repo.save(any(CrewEntity.class))).thenReturn(existingCrew); 
      CrewEntity result = service.updateCrew(crid, updatedCrew);
      assertEquals("John Smith", result.getName());
      assertEquals("johnsmith@example.com", result.getEmail());
      assertEquals("0987654321", result.getMobile());
      verify(repo, times(1)).save(existingCrew);
   }
}






   //  @Test
   //  void updateCrew_shouldThrowExceptionWhenCrewNotFound() {
   //      String crid = "CR01";
   //      CrewEntity updatedCrew = new CrewEntity(crid, "PH01", "ADMIN", "John Smith", "johnsmith@example.com", "0987654321", "ABCDE1234F");

   //      when(repo.findById(crid)).thenReturn(Optional.empty());

   //      assertThrows(RuntimeException.class, () -> service.updateCrew(crid, updatedCrew));
   //  }